"""Central playback queue for the prerecorded voice. No overlap, no repeats."""
import os, threading
from collections import deque


class AudioManager:
    def __init__(self, player, root, on_busy=None, on_idle=None, exts=('.ogg', '.mp3')):
        self.player, self.root, self.exts = player, root, exts
        self.on_busy, self.on_idle = on_busy, on_idle
        self._q, self._cur, self._gen, self._busy = deque(), None, 0, False
        self._lock, self.missing = threading.RLock(), set()

    @property
    def busy(self):
        return self._busy

    def resolve(self, lang, key):
        for e in self.exts:
            p = os.path.join(self.root, lang, key + e)
            if os.path.isfile(p):
                return p
        return None

    def play(self, lang, keys, interrupt=False):
        with self._lock:
            if interrupt:
                self._q.clear()
                if self._cur is not None:
                    self._gen += 1                  # stale completion callbacks are ignored
                    self._cur = None
                    self.player.stop()
            for k in keys:
                if self._q and self._q[-1] == (lang, k):
                    continue                        # prevent repeated playback
                if not self._q and self._cur == (lang, k):
                    continue
                self._q.append((lang, k))
            if self._cur is None:
                self._advance()

    def _advance(self):
        while self._q:
            lang, key = self._q.popleft()
            path = self.resolve(lang, key)
            if not path:
                self.missing.add((lang, key))       # UI still shows the subtitle
                continue
            if not self._busy:
                self._busy = True
                if self.on_busy:
                    self.on_busy()
            self._gen += 1
            gen, self._cur = self._gen, (lang, key)
            try:
                self.player.play(path, lambda g=gen: self._done(g))
                return
            except Exception:
                self._cur = None
        self._cur = None
        if self._busy:
            self._busy = False
            if self.on_idle:
                self.on_idle()

    def _done(self, gen):
        with self._lock:
            if gen == self._gen:
                self._cur = None
                self._advance()

    def stop(self):
        with self._lock:
            self._q.clear(); self._gen += 1; self._cur = None
            self.player.stop()
            if self._busy:
                self._busy = False
                if self.on_idle:
                    self.on_idle()

    def release(self):
        self.stop(); self.player.release()

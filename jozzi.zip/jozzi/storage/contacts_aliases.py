"""Contact aliases: 'مامان' / 'Mom' / 'Mother' -> a chosen contact. Local only."""
from core.text_normalizer import normalize
from .database import JsonStore

GROUPS = [{'مامان', 'مادر', 'mom', 'mother', 'mum', 'mommy', 'maman'},
          {'بابا', 'پدر', 'dad', 'father', 'daddy', 'baba'}]


def _group(key):
    for g in GROUPS:
        if key in g:
            return {normalize(x) for x in g}
    return {key}


class AliasStore:
    def __init__(self, directory=None):
        self.s = JsonStore('aliases.json', {}, directory)

    def resolve(self, name):
        return self.s.load().get(normalize(name))        # {'name':..., 'number':...} or None

    def set(self, alias, contact_name, number=None, with_synonyms=True):
        key = normalize(alias)
        d = self.s.load()
        for k in (_group(key) if with_synonyms else {key}):
            d[k] = {'name': contact_name, 'number': number}
        self.s.save()

    edit = set

    def delete(self, alias):
        d = self.s.load()
        d.pop(normalize(alias), None)
        self.s.save()

    def all(self):
        return dict(self.s.load())

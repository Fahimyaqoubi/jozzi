"""Tiny atomic JSON store, safe to share between the UI and service processes."""
import json, os, threading


def data_dir():
    d = os.environ.get('JOZZI_DATA') or os.environ.get('ANDROID_PRIVATE') or os.path.expanduser('~/.jozzi')
    os.makedirs(d, exist_ok=True)
    return d


class JsonStore:
    def __init__(self, name, default=None, directory=None):
        self.path = os.path.join(directory or data_dir(), name)
        self.default, self._lock, self._mtime, self._data = default or {}, threading.RLock(), None, None

    def load(self):
        with self._lock:
            try:
                m = os.path.getmtime(self.path)
            except OSError:
                m = None
            if self._data is None or m != self._mtime:     # reload if another process wrote it
                try:
                    with open(self.path, encoding='utf-8') as f:
                        self._data = json.load(f)
                except (OSError, ValueError):
                    self._data = json.loads(json.dumps(self.default))
                self._mtime = m
            return self._data

    def save(self):
        with self._lock:
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self._data, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)
            self._mtime = os.path.getmtime(self.path)

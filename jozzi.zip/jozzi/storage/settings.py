from .database import JsonStore

DEFAULTS = {'ui_language': 'fa', 'recognition_language': 'fa', 'allow_offline_only': True,
            'confirm_before_call': True, 'app_aliases': {}}


class Settings:
    def __init__(self, directory=None):
        self.s = JsonStore('settings.json', DEFAULTS, directory)

    def get(self, key, default=None):
        return self.s.load().get(key, DEFAULTS.get(key, default))

    def set(self, key, value):
        self.s.load()[key] = value
        self.s.save()

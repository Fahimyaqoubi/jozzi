# Jozzi — Privacy Policy (draft, review before publishing)

Jozzi works offline. It does not require an account and has no server.
* **Microphone**: audio is processed on your device by an offline speech engine to detect “جوزی / Hey Jozzi” and to understand commands while active. Audio is not recorded to storage, not uploaded, not shared.
* **Contacts**: read on-device only to find the person you name. Names and numbers are not uploaded and not written to logs. Aliases you create are stored locally in the app’s private storage.
* **Installed apps list**: read on-device only to open the app you ask for.
* **Music**: audio file titles are read from the device media library to play them; nothing leaves the device.
* **Messages / calls / alarms**: Jozzi opens your messaging app, dialer or clock app with prepared content; you confirm in that app.
* **Permissions** are requested when needed and can be revoked in Android settings; features depending on them stop working.
* The app shows a persistent notification and the Android microphone indicator while the background service listens. You can stop listening from the app or notification.
* No analytics, no ads, no third-party SDK that transmits data.
Contact: Fahim Yaqoobi — add your email/URL here before publishing.

# Jozzi — offline Persian/English voice assistant for Android (Python / Kivy)

Creator: Fahim Yaqoobi · Version 0.1.0 · Package `org.jozzi.jozzi`

## Honest status

| Area | State |
|---|---|
| Text normalisation, language detection, intent parsing (fa / en / mixed) | **Done, unit-tested** |
| Time parsing (absolute, relative, midnight, AM/PM follow-up) | **Done, unit-tested** |
| Multi-turn conversation (missing info, confirm, cancel, timeout, interrupt, contact choice) | **Done, unit-tested** |
| 5-minute ACTIVE→STANDBY timeout, disable/enable, music ducking, audio queue | **Done, unit-tested** (fake clock / fake player) |
| Contacts, aliases, app launcher, music playlist logic | **Done, unit-tested** (pure-Python parts) |
| Android glue (Pyjnius: contacts, intents, alarm, MediaPlayer, MediaStore, Vosk, service start) | **Written, NEVER RUN on a device** — treat as untested |
| Kivy UI + orb | **Written, never run** (Kivy was not installable in the authoring sandbox) |
| Java `MediaSessionBridge` | **Written, never compiled** |
| **APK build** | **NOT built** — authoring sandbox had no network / Android SDK. Run `buildozer android debug` yourself |
| **Voice files** | **NOT generated** — no audio tool available. `assets/audio/{fa,en}/` are empty. Manifest + generator script provided (below) |
| Offline speech models | **NOT included** (see below) |
| Notification transport controls for music | **Not implemented** (MediaSession only: lock-screen / headset buttons) |
| Real-device tests (`tests/device_checklist.md`) | **Not done** |

Until the audio files exist the app still works: every reply is shown as a subtitle.

## Run the unit tests (no Android needed)
```
python3 -m unittest discover -s tests -t .
```

## 1. Voice files (required before release)
`tools/recording_manifest.csv` lists the 27 clips per language (23 required + 4 small extras:
`call_confirm`, `which_one`, `to_whom`, `listening_off`).
Option A – synthesize on your dev PC (internet only at dev time): `pip install edge-tts`, install ffmpeg,
`python tools/generate_audio.py` → mono OGG, trimmed silence, loudness-normalised, in `assets/audio/fa|en/`.
Option B – record real voice and save with the same file names. Listen to every Persian clip before shipping.
Dynamic text (contact names, song titles) is never spoken — subtitles only. The clip “چی به مامان بگم؟”
is used when the spoken contact was Mom/مامان; other contacts use the generic “چی می‌خواستی بگی؟” + subtitle with the name.

## 2. Offline speech models (required)
Uses **Vosk** (Apache-2.0, fully offline). Download and unzip so the folders look like:
```
assets/models/fa/   (e.g. vosk-model-small-fa-0.42 contents)
assets/models/en/   (e.g. vosk-model-small-en-us-0.15 contents)
```
(≈40–50 MB each; check current names at alphacephei.com/vosk/models.) Only `fa` is needed for the wake word.
If a model is missing the UI says so; **there is no online fallback, ever.**
Design: STANDBY = recogniser restricted to the grammar `["جوزی","هی جوزی"]` (cheap). ACTIVE = full small model of the language chosen in Settings.
Known limits you must test: (1) “Hey Jozzi” said in English is matched through the Persian model, accuracy unknown; (2) the Persian model cannot recognise English app names — that is why Persian aliases (کلاد, کروم…) exist; (3) one language per ACTIVE session (Settings), mixed sentences work only as far as the chosen model knows the words; (4) small models are not great with names.
If wake accuracy is poor, swap in a trained keyword model behind `platform_android/speech.py` (the rest of the app only sees `on_wake` / `on_text`).

## 3. Build
```
pip install buildozer cython
python tools/make_icon.py        # already done once
buildozer android debug          # first run downloads SDK/NDK (needs internet)
adb install -r bin/jozzi-0.1.0-*-debug.apk
```
Things to VERIFY on first build (written from memory, not tested): `vosk-android` / `jna` versions in `buildozer.spec`;
the exact `ServiceJozzi.start(...)` signature of your python-for-android version (`platform_android/background_service.py`);
that the service manifest entry carries `android:foregroundServiceType="microphone"` (inspect the merged
AndroidManifest in `.buildozer/android/platform/build-*/dists/jozzi/src/main/AndroidManifest.xml`; if missing, add it via
`android.extra_manifest_application_arguments` / a custom manifest template). Android 14 crashes the service without it.

## Android limits you cannot code around
* **Mic in background**: needs a foreground service with type `microphone`, started while the app is visible (Android 14+), a persistent notification, and shows the system mic indicator (Android 12+). Force-stop, aggressive OEM battery savers (Xiaomi, Huawei, Samsung…) and Doze can kill or starve it — users may need to exempt Jozzi from battery optimisation. No guarantee after force-stop or reboot (no auto-start implemented).
* **Starting apps/dialer/SMS from the background service** is restricted on Android 10+ (background activity start). It works while Jozzi’s UI is visible and often with screen on; from a locked/backgrounded state it may silently do nothing. `startActivity` gives no error in that case — the app can’t always detect it. Workaround (not implemented): “display over other apps” permission or a tap-to-open notification.
* **Messages**: Jozzi opens SMS/WhatsApp with the text prefilled; the user presses send. It can’t confirm delivery, so it never says “sent”. Telegram cannot prefill a recipient (chat picker opens).
* **Calls**: opens the dialer (`ACTION_DIAL`); no CALL_PHONE permission requested.
* **Alarms**: `AlarmClock.ACTION_SET_ALARM`. Android returns no result, so success means “the clock app accepted the intent”; check the clock app on test devices.
* **Package visibility** (Android 11+): launchable apps are found via a `<queries>` MAIN/LAUNCHER entry; some apps may stay invisible.
* Music: only files indexed by MediaStore; needs READ_MEDIA_AUDIO (Android 13+) / READ_EXTERNAL_STORAGE.

## 4. Release & signing
```
keytool -genkeypair -v -keystore jozzi-release.jks -alias jozzi -keyalg RSA -keysize 4096 -validity 10000
buildozer android release        # android.release_artifact = apk
zipalign -v -p 4 bin/jozzi-0.1.0-*-release-unsigned.apk jozzi-aligned.apk
apksigner sign --ks jozzi-release.jks --out jozzi-0.1.0.apk jozzi-aligned.apk
apksigner verify --verbose jozzi-0.1.0.apk
```
Keep the keystore + passwords safe: stores require the same key for every update. Store text: `STORE_LISTING.md`; privacy policy draft: `PRIVACY.md`.
Cafe Bazaar / Myket: submit via their developer panels; follow their current policies (permissions justification for microphone, contacts; privacy policy URL). Nothing here is approved or reviewed by either store.

## Troubleshooting
* Persian text shows boxes → add `assets/fonts/Vazirmatn-Regular.ttf` (OFL font, not bundled).
* Persian text reversed/disconnected → `arabic-reshaper` / `python-bidi==0.4.2` missing from requirements.
* Status bar says “Offline speech model missing” → see §2.
* Service dies on Android 14 → foreground service type, §3. Dies after some minutes → OEM battery settings.
* Nothing opens when the screen is off → background-activity limit above.
* Contacts / music empty → grant permission from Settings → “Contacts perm” / “Audio perm”, then “Refresh”.
* `adb logcat | grep -i python` for crashes. Contact numbers are never logged by the code.

## Layout (changes from the brief)
`android/` was renamed **`platform_android/`** — a package called `android` would shadow python-for-android’s own `android` module
(`android.permissions`, …). Audio lives in `assets/audio/{fa,en}` as the brief’s §6 specifies. `core/ipc.py` + `service.py` were added: p4a services
run in their own process, so the UI talks to the assistant over localhost OSC (text only).

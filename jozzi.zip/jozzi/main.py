import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from kivy.app import App
from kivy.clock import Clock
from kivy.core.window import Window
from kivy.uix.screenmanager import ScreenManager, NoTransition
from config import OSC_SERVICE_PORT, OSC_UI_PORT
from core.ipc import Channel
from storage.contacts_aliases import AliasStore
from storage.settings import Settings
from ui.screens import MainScreen, SettingsScreen, BG, set_text

ON_ANDROID = 'ANDROID_ARGUMENT' in os.environ


class JozziApp(App):
    title = 'Jozzi'

    def build(self):
        Window.clearcolor = BG
        self.settings, self.aliases = Settings(), AliasStore()
        self.chan = Channel(OSC_UI_PORT, OSC_SERVICE_PORT)
        sm = self.sm = ScreenManager(transition=NoTransition())
        self.main = MainScreen(lambda: self.chan.send('activate'), lambda: self.chan.send('disable'),
                               lambda: setattr(sm, 'current', 'settings'), lambda t: self.chan.send('text', t),
                               name='main')
        sm.add_widget(self.main)
        sm.add_widget(SettingsScreen(self.settings, self.aliases, lambda: setattr(sm, 'current', 'main'),
                                     lambda: self.chan.send('refresh'), self._perm, name='settings'))
        ui = lambda f: (lambda *a: Clock.schedule_once(lambda dt: f(*a)))   # OSC thread -> UI thread
        m = self.main
        self.chan.bind('orb', ui(lambda v: (setattr(m.orb, 'state', v), set_text(m.state, v))))
        self.chan.bind('mode', ui(lambda v: set_text(m.state, v)))
        self.chan.bind('heard', ui(lambda v: set_text(m.heard, v)))
        self.chan.bind('subtitle', ui(lambda v: set_text(m.sub, v)))
        self.chan.bind('status', ui(lambda v: set_text(m.status, self._status(v))))
        if ON_ANDROID:
            from platform_android.background_service import request_permissions, start_service
            request_permissions(lambda perms, res: Clock.schedule_once(lambda dt: start_service()) if all(res) else
                                set_text(m.status, 'Microphone permission denied — assistant is off'))
        else:
            set_text(m.status, 'desktop: UI only (service not running)')
        return sm

    @staticmethod
    def _status(v):
        if v.startswith('offline_model_missing'):
            return 'Offline speech model missing (' + v.split(':')[1] + '). No online fallback is used.'
        if v.startswith('models:'):
            return 'Offline models: ' + (v[7:] or 'NONE installed')
        return v

    def _perm(self, kind):
        if ON_ANDROID:
            from platform_android.background_service import request_optional
            request_optional(kind)

    def on_pause(self):
        self.main.orb.pause(); return True

    def on_resume(self):
        self.main.orb.resume()


if __name__ == '__main__':
    JozziApp().run()

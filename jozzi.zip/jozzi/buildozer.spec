[app]
title = Jozzi
package.name = jozzi
package.domain = org.jozzi
source.dir = .
source.include_exts = py,png,jpg,json,ogg,mp3,ttf,txt,md
source.include_patterns = assets/*,assets/*/*,assets/models/*/*,assets/models/*/*/*
source.exclude_dirs = tests,tools,.buildozer,bin
version = 0.1.0
requirements = python3,kivy==2.3.0,pyjnius,oscpy,arabic-reshaper,python-bidi==0.4.2,six
icon.filename = %(source.dir)s/assets/icons/icon.png
orientation = portrait
fullscreen = 0

# foreground service in its own process; microphone type is mandatory on Android 14+
services = Jozzi:service.py:foreground:sticky
android.permissions = RECORD_AUDIO,FOREGROUND_SERVICE,FOREGROUND_SERVICE_MICROPHONE,POST_NOTIFICATIONS,READ_CONTACTS,READ_MEDIA_AUDIO,READ_EXTERNAL_STORAGE,SET_ALARM,WAKE_LOCK,MODIFY_AUDIO_SETTINGS
# NOT requested on purpose: CALL_PHONE, SEND_SMS, QUERY_ALL_PACKAGES, SYSTEM_ALERT_WINDOW

android.api = 34
android.minapi = 26
android.archs = arm64-v8a, armeabi-v7a
android.enable_androidx = True
android.add_src = android_native/java
android.extra_manifest_xml = android_native/manifest_extra.xml
# Vosk offline recogniser (+JNA). VERIFY the versions exist before building.
android.gradle_dependencies = com.alphacephei:vosk-android:0.3.47, net.java.dev.jna:jna:5.13.0@aar
android.release_artifact = apk
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 1

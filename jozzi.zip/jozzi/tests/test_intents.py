import unittest
from core.intent_parser import parse
from platform_android.wake_word import is_wake


class T(unittest.TestCase):
    def chk(self, utt, name, **slots):
        it = parse(utt)
        self.assertEqual(it.name, name, utt)
        for k, v in slots.items():
            self.assertEqual(it.slots.get(k), v, f'{utt}: {k}')
        return it

    def test_wake(self):
        self.assertEqual(parse('جوزی').name, 'WAKE')
        self.assertEqual(parse('Hey Jozzi').name, 'WAKE')
        self.assertTrue(is_wake('هی جوزی'))
        self.assertTrue(is_wake('hey jozzi'))
        self.assertFalse(is_wake('سلام دنیا'))

    def test_message_fa(self):
        self.chk('جوزی به مامان پیام بده.', 'MESSAGE', contact='مامان', text='')
        self.chk('به مامان بگو سلام خوبی؟', 'MESSAGE', contact='مامان', text='سلام خوبی؟')
        self.chk('به مامان پیام بده که دیر میام', 'MESSAGE', contact='مامان', text='دیر میام')
        self.chk('به مامان در تلگرام پیام بده', 'MESSAGE', contact='مامان', app='telegram')

    def test_message_en_mixed(self):
        self.chk('Hey Jozzi, message mom.', 'MESSAGE', contact='mom', text='')
        self.chk('Tell mom hello', 'MESSAGE', contact='mom', text='hello')
        self.chk("Message mom and say I'm coming", 'MESSAGE', contact='mom', text="I'm coming")
        it = self.chk('Hey Jozzi message to mom سلام خوبی؟', 'MESSAGE', contact='mom', text='سلام خوبی؟')
        self.assertEqual(it.lang, 'en')

    def test_call(self):
        self.chk('به مامان زنگ بزن', 'CALL', contact='مامان')
        self.chk('با بابا تماس بگیر', 'CALL', contact='بابا')
        self.chk('Call mom', 'CALL', contact='mom')

    def test_open(self):
        self.chk('کلاد رو باز کن.', 'OPEN', app='کلاد')
        self.chk('کروم رو اجرا کن', 'OPEN', app='کروم')
        self.chk('تلفن رو باز کن', 'OPEN', app='تلفن')
        self.chk('Open Claude', 'OPEN', app='Claude')
        self.chk('Open Phone', 'OPEN', app='Phone')

    def test_music(self):
        self.chk('یه آهنگ رندوم پخش کن', 'MUSIC_RANDOM')
        self.chk('Play random music', 'MUSIC_RANDOM')
        self.chk('آهنگ بعدی', 'MUSIC_NEXT')
        self.chk('Next song', 'MUSIC_NEXT')
        self.chk('آهنگ قبلی رو بذار', 'MUSIC_PREV')
        self.chk('موسیقی رو متوقف کن', 'MUSIC_STOP')
        self.chk('Pause music', 'MUSIC_PAUSE')
        self.chk('Resume music', 'MUSIC_RESUME')
        self.chk('Play a song named Yesterday', 'MUSIC_NAMED', query='Yesterday')

    def test_alarm(self):
        for t in ('جوزی آلارم بذار', 'ساعت ۶:۳۰ آلارم بذار', 'نیم ساعت دیگه بیدارم کن', 'Set an alarm in 40 minutes'):
            self.chk(t, 'ALARM')

    def test_control_and_identity(self):
        self.chk('جوزی فعلاً گوش نده', 'STOP_LISTEN')
        self.chk('Stop listening', 'STOP_LISTEN')
        self.chk('Disable assistant', 'STOP_LISTEN')
        self.chk('لغو کن', 'CANCEL')
        self.chk('Cancel', 'CANCEL')
        self.chk('Who created you?', 'WHO')
        self.chk('کی تو رو ساخته؟', 'WHO')

    def test_unknown(self):
        self.chk('هوا امروز چطوره', 'UNKNOWN')


if __name__ == '__main__':
    unittest.main()

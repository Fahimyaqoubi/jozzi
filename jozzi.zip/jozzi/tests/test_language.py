import unittest
from core.language_detector import detect, command_language
from core.text_normalizer import normalize, clean


class T(unittest.TestCase):
    def test_detect(self):
        self.assertEqual(detect('کلاد رو باز کن'), 'fa')
        self.assertEqual(detect('Open Claude'), 'en')
        self.assertEqual(detect('Hey Jozzi message to mom سلام خوبی؟'), 'mixed')

    def test_command_language(self):
        self.assertEqual(command_language('message to mom سلام'), 'en')
        self.assertEqual(command_language('کلاد open'), 'fa')

    def test_arabic_persian_chars(self):
        self.assertEqual(normalize('كتاب يك'), normalize('کتاب یک'))

    def test_digits_and_halfspace(self):
        self.assertEqual(normalize('ساعت ۶:۳۰'), 'ساعت 6:30')
        self.assertEqual(normalize('می‌دم'), 'می دم')
        self.assertEqual(clean('می‌دم'), 'می‌دم')       # message text keeps the half-space

    def test_diacritics(self):
        self.assertEqual(normalize('فعلاً'), 'فعلا')


if __name__ == '__main__':
    unittest.main()

import unittest
from datetime import datetime
from core.command_router import CommandRouter
from platform_android.contacts import Contact
from storage.contacts_aliases import AliasStore
from tests.fakes import make_platform, Clock
import tempfile


class T(unittest.TestCase):
    def setUp(self):
        self.p = make_platform()
        self.clock = Clock()
        self.now = datetime(2026, 11, 10, 14, 0, 0)
        self.aliases = AliasStore(tempfile.mkdtemp())
        self.r = CommandRouter(self.p, self.aliases, lambda: self.now, self.clock)

    def say(self, text):
        return self.r.handle(text)

    def test_message_flow_spec_example(self):
        r = self.say('جوزی به مامان پیام بده.')
        self.assertEqual(r.keys, ['what_to_say_mom'])
        r = self.say('سلام مامان خوبی؟')
        self.assertEqual(r.keys, ['message_ready', 'send_it'])
        self.assertIn('سلام مامان خوبی؟', r.subtitle)
        self.assertEqual(self.p.messaging.sent, [])            # nothing sent before confirmation
        r = self.say('آره')
        self.assertEqual(self.p.messaging.sent, [('09121111111', 'سلام مامان خوبی؟', None)])
        self.assertEqual(r.keys, ['opening_app'])

    def test_message_text_is_never_taken_as_command(self):
        self.say('به مامان پیام بده')
        r = self.say('کروم رو باز کن')                          # this IS the message
        self.assertEqual(self.p.launcher.launched, [])
        self.assertEqual(r.keys, ['message_ready', 'send_it'])

    def test_message_inline_text_goes_straight_to_confirm(self):
        r = self.say('به مامان بگو سلام خوبی؟')
        self.assertEqual(r.keys, ['message_ready', 'send_it'])

    def test_decline_confirmation(self):
        self.say('به مامان بگو سلام'); r = self.say('نه')
        self.assertEqual(r.keys, ['cancelled']); self.assertEqual(self.p.messaging.sent, [])

    def test_cancel_midflow_then_yes_is_not_a_command(self):
        self.say('به مامان پیام بده')
        self.assertEqual(self.say('لغو کن').keys, ['cancelled'])
        self.assertEqual(self.say('آره').keys, ['not_understood', 'repeat'])

    def test_interrupt_confirmation_with_new_command(self):
        self.say('به مامان بگو سلام')
        r = self.say('کروم رو باز کن')
        self.assertEqual(self.p.launcher.launched, ['com.android.chrome'])
        self.assertEqual(self.p.messaging.sent, [])
        self.assertIsNone(self.r.conv.pending)

    def test_alarm_spec_example(self):
        self.assertEqual(self.say('جوزی آلارم بذار').keys, ['what_time'])
        self.assertEqual(self.say('شش و نیم').keys, ['am_or_pm'])
        r = self.say('صبح')
        self.assertEqual(self.p.alarms.alarms, [(6, 30)])
        self.assertEqual(r.keys, ['alarm_set'])
        self.assertIn('۶:۳۰ صبح', r.subtitle)

    def test_alarm_relative_and_english(self):
        self.say('چهل دقیقه دیگه آلارم بذار'); self.assertEqual(self.p.alarms.alarms[-1], (14, 40))
        self.say('Set an alarm in 40 minutes'); self.assertEqual(self.p.alarms.alarms[-1], (14, 40))
        self.now = datetime(2026, 11, 10, 23, 50)
        self.say('Set an alarm in 40 minutes'); self.assertEqual(self.p.alarms.alarms[-1], (0, 30))

    def test_alarm_rejected_by_system_is_not_reported_as_success(self):
        self.p.alarms.ok = False
        r = self.say('ساعت ۱۴:۴۵ آلارم بذار')
        self.assertEqual(r.keys, ['failed']); self.assertFalse(r.success)

    def test_alarm_english_flow(self):
        self.assertEqual(self.say('Set an alarm').keys, ['what_time'])
        self.assertEqual(self.say('7').keys, ['am_or_pm'])
        self.say('PM'); self.assertEqual(self.p.alarms.alarms, [(19, 0)])

    def test_pending_timeout(self):
        self.say('آلارم بذار'); self.clock.t = 61
        self.assertEqual(self.say('آره').keys, ['not_understood', 'repeat'])

    def test_contact_not_found_and_alias(self):
        self.assertEqual(self.say('به رضا پیام بده').keys, ['contact_not_found'])
        self.aliases.set('داداش', 'بابا')
        self.say('به داداش بگو سلام'); self.say('آره')
        self.assertEqual(self.p.messaging.sent[0][0], '09122222222')

    def test_duplicate_contacts_ask_to_choose(self):
        self.p.contacts.set([Contact('علی', ['0911']), Contact('علی', ['0912'])])
        r = self.say('به علی زنگ بزن')
        self.assertEqual(r.keys, ['which_one'])
        r = self.say('دومی'); self.assertEqual(r.keys, ['call_confirm'])
        self.say('آره'); self.assertEqual(self.p.calling.dialed, ['0912'])

    def test_call_requires_confirmation(self):
        r = self.say('Call mom')                                  # 'mom' has no alias yet -> not found
        self.assertEqual(r.keys, ['contact_not_found'])
        self.say('به مامان زنگ بزن'); self.assertEqual(self.p.calling.dialed, [])
        self.say('بله'); self.assertEqual(self.p.calling.dialed, ['09121111111'])

    def test_alias_synonyms_mom_mother(self):
        self.aliases.set('مامان', 'مامان')
        self.assertEqual(self.aliases.resolve('Mom')['name'], 'مامان')
        self.say('Message mom and say hi'); self.say('yes')
        self.assertEqual(self.p.messaging.sent[0][1], 'hi')

    def test_apps(self):
        self.say('کلاد رو باز کن'); self.assertEqual(self.p.launcher.launched, ['com.anthropic.claude'])
        self.say('Open Phone'); self.assertEqual(self.p.launcher.launched[-1], 'special:dial')
        self.assertEqual(self.say('اینستاگرام رو باز کن').keys, ['app_not_found'])

    def test_music_commands(self):
        r = self.say('یه آهنگ رندوم پخش کن'); self.assertEqual(r.keys, ['playing_music']); self.assertTrue(self.p.backend.playing)
        self.say('آهنگ بعدی'); self.say('Pause music'); self.assertFalse(self.p.backend.playing)
        self.say('Resume music'); self.assertTrue(self.p.backend.playing)
        self.say('موسیقی رو متوقف کن'); self.assertFalse(self.p.backend.playing)

    def test_random_music_without_library(self):
        p = make_platform(tracks=[]); r = CommandRouter(p, self.aliases)
        self.assertEqual(r.handle('Play random music').keys, ['failed'])

    def test_identity(self):
        self.assertIn('Fahim Yaqoobi', self.say('Who created you?').subtitle)
        self.assertIn('فهیم یعقوبی', self.say('کی تو رو ساخته').subtitle)

    def test_stop_listening(self):
        self.assertEqual(self.say('جوزی فعلاً گوش نده').mode, 'disabled')


if __name__ == '__main__':
    unittest.main()

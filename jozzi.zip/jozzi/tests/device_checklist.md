# Device-dependent tests (NOT yet run — fill in per device/Android version)
For each device record model, Android version, result, notes.
1. Offline fa recognition works in airplane mode (STANDBY wake + ACTIVE commands)
2. Offline en recognition works in airplane mode
3. Mixed command accuracy ("Hey Jozzi message to mom …")
4. Wake word "جوزی" and "Hey Jozzi": hit rate, false triggers (TV/people talking) over 1 h
5. Screen locked: service alive after 10 min / 1 h; battery % drop per hour (measure, don't guess); RAM via `adb shell dumpsys meminfo org.jozzi.jozzi`
6. Android 14: service starts, mic type notification shown; Android 13/12/11 behaviour
7. 5-minute ACTIVE timeout on real clock; manual activate/disable from UI and notification
8. Contacts: Persian/English names, duplicates, multiple numbers, permission revoked mid-session
9. SMS/WhatsApp/Telegram prefilled intents; dialer; from foreground AND from locked/background
10. Open Claude/Chrome/Telegram/Phone/Settings; app not installed
11. Random music, next/prev/pause/resume/stop, volume; ducking while Jozzi speaks; headset buttons
12. Alarm: absolute, relative, past midnight, timezone change, clock app rejects intent
13. Missing permissions: mic, contacts, audio, notifications, SET_ALARM
14. Audio queue: rapid commands, no overlap, no crash after 100 commands (leak check)
15. OEM battery savers (Xiaomi/Samsung/Huawei): does the service survive?

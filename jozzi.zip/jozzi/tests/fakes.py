from types import SimpleNamespace
from platform_android.app_launcher import AppIndex
from platform_android.contacts import Contact, ContactBook
from platform_android.music import MusicController, Playlist
import random


class FakeMessaging:
    def __init__(self): self.sent = []
    def open(self, number, text, app=None): self.sent.append((number, text, app)); return True


class FakeCalling:
    def __init__(self): self.dialed = []
    def dial(self, n): self.dialed.append(n); return True


class FakeAlarms:
    def __init__(self, ok=True): self.alarms, self.ok = [], ok
    def set_alarm(self, h, m, label=''):
        if self.ok: self.alarms.append((h, m))
        return self.ok


class FakeLauncher:
    def __init__(self):
        self.index = AppIndex([('Claude', 'com.anthropic.claude'), ('Chrome', 'com.android.chrome'),
                               ('Telegram', 'org.telegram.messenger')])
        self.launched = []
    def find(self, q): return self.index.find(q)
    def launch(self, app): self.launched.append(app.package); return True


class FakeBackend:
    def __init__(self, items): self.items, self.playing, self.log, self.volume = items, False, [], 1.0
    def load_library(self): return self.items
    def start(self, it): self.playing = True; self.log.append(('start', it[1]))
    def pause(self): self.playing = False
    def resume(self): self.playing = True
    def stop(self): self.playing = False
    def set_volume(self, v): self.volume = v
    def is_playing(self): return self.playing


class FakeSpeech:
    def __init__(self): self.calls = []
    def start_wake(self): self.calls.append('wake')
    def start_command(self, lang='fa'): self.calls.append('command')
    def pause(self): self.calls.append('pause')
    def resume(self): self.calls.append('resume')
    def stop(self): self.calls.append('stop')


class FakePlayer:
    def __init__(self): self.played, self.cb, self.stops = [], None, 0
    def play(self, path, cb): self.played.append(path); self.cb = cb
    def stop(self): self.stops += 1
    def release(self): pass
    def finish(self): cb, self.cb = self.cb, None; cb()


def make_platform(contacts=None, tracks=None):
    contacts = contacts if contacts is not None else [Contact('مامان', ['09121111111']), Contact('بابا', ['09122222222'])]
    backend = FakeBackend(tracks if tracks is not None else [(1, 'Song A'), (2, 'Song B'), (3, 'Song C')])
    return SimpleNamespace(contacts=ContactBook(contacts), messaging=FakeMessaging(), calling=FakeCalling(),
                           alarms=FakeAlarms(), launcher=FakeLauncher(), speech=FakeSpeech(),
                           music=MusicController(backend, Playlist(random.Random(1))), backend=backend)


class Clock:
    def __init__(self, t=0.0): self.t = t
    def __call__(self): return self.t

import os, tempfile, unittest
from audio.audio_manager import AudioManager
from core.assistant import Assistant
from core.state_manager import StateManager, Mode
from platform_android.music import Playlist
from storage.contacts_aliases import AliasStore
from storage.settings import Settings
from tests.fakes import FakePlayer, make_platform, Clock
import random


class TestState(unittest.TestCase):
    def test_five_minute_timeout_and_reset(self):
        c = Clock(); s = StateManager(c); s.activate()
        c.t = 299; self.assertFalse(s.tick())
        s.touch(); c.t = 598; self.assertFalse(s.tick())         # command reset the timer
        c.t = 599; self.assertTrue(s.tick()); self.assertEqual(s.mode, Mode.STANDBY)

    def test_disabled_ignores_wake(self):
        s = StateManager(Clock()); s.disable(); self.assertFalse(s.activate()); self.assertEqual(s.mode, Mode.DISABLED)
        s.force_activate(); self.assertEqual(s.mode, Mode.ACTIVE)


class TestAudio(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp(); os.makedirs(os.path.join(self.root, 'fa'))
        for k in ('a', 'b', 'c'):
            with open(os.path.join(self.root, 'fa', k + '.ogg'), 'wb') as f:
                f.write(b'x')
        self.pl, self.ev = FakePlayer(), []
        self.am = AudioManager(self.pl, self.root, lambda: self.ev.append('busy'), lambda: self.ev.append('idle'))

    def test_queue_no_overlap(self):
        self.am.play('fa', ['a', 'b'])
        self.assertEqual(len(self.pl.played), 1)                  # b waits for a
        self.pl.finish(); self.assertEqual(len(self.pl.played), 2)
        self.pl.finish(); self.assertEqual(self.ev, ['busy', 'idle'])

    def test_no_repeat_and_missing_files_skipped(self):
        self.am.play('fa', ['a', 'a', 'zzz', 'b'])
        self.pl.finish(); self.pl.finish()
        self.assertEqual([os.path.basename(p) for p in self.pl.played], ['a.ogg', 'b.ogg'])
        self.assertIn(('fa', 'zzz'), self.am.missing)

    def test_interrupt_ignores_stale_completion(self):
        self.am.play('fa', ['a']); stale = self.pl.cb
        self.am.play('fa', ['b'], interrupt=True)
        stale()                                                    # old clip's callback fires late
        self.assertEqual(len(self.pl.played), 2)
        self.assertEqual(self.pl.stops, 1)
        self.assertEqual(self.ev, ['busy'])                        # still one continuous busy period

    def test_release(self):
        self.am.play('fa', ['a']); self.am.release(); self.assertEqual(self.ev, ['busy', 'idle'])


class TestMusic(unittest.TestCase):
    def test_shuffle_covers_all_and_wraps(self):
        pl = Playlist(random.Random(3)); pl.load([(i, f't{i}') for i in range(5)])
        seen = [pl.next()[0] for _ in range(5)]
        self.assertEqual(sorted(seen), [0, 1, 2, 3, 4])
        self.assertEqual(pl.next()[0], seen[0])

    def test_prev_goes_back(self):
        pl = Playlist(random.Random(3)); pl.load([(i, f't{i}') for i in range(4)])
        a, b = pl.next(), pl.next(); self.assertEqual(pl.prev(), a)

    def test_search_persian_variants(self):
        pl = Playlist(); pl.load([(1, 'يه آهنگ'), (2, 'Other')])
        self.assertEqual(pl.search('یه آهنگ'), [(1, 'يه آهنگ')])


class TestAssistant(unittest.TestCase):
    def setUp(self):
        self.p, self.clock, self.pl = make_platform(), Clock(), FakePlayer()
        root = tempfile.mkdtemp()
        for lang in ('fa', 'en'):
            os.makedirs(os.path.join(root, lang))
        d = tempfile.mkdtemp()
        self.ev = []
        self.audio = AudioManager(self.pl, root)
        self.a = Assistant(self.p, self.audio, AliasStore(d), Settings(d), lambda k, v='': self.ev.append((k, v)),
                           clock=self.clock)
        self.a.start()

    def test_wake_session_timeout_standby(self):
        self.assertEqual(self.p.speech.calls[-1], 'wake')
        self.a.on_speech('آهنگ رندوم')                              # STANDBY: ordinary commands ignored
        self.assertFalse(self.p.backend.playing)
        self.a.on_wake(); self.assertEqual(self.a.state.mode, Mode.ACTIVE)
        self.a.on_speech('یه آهنگ رندوم پخش کن'); self.assertTrue(self.p.backend.playing)   # no wake word needed
        self.a.on_speech('آهنگ بعدی')
        self.clock.t = 299; self.a.tick(); self.assertEqual(self.a.state.mode, Mode.ACTIVE)
        self.clock.t = 700; self.a.tick(); self.assertEqual(self.a.state.mode, Mode.STANDBY)
        self.assertEqual(self.p.speech.calls[-1], 'wake')

    def test_music_ducked_during_interaction_then_restored(self):
        self.a.on_speech('x'); self.p.music.play_random(); self.p.backend.volume = 0.8
        self.a.on_wake(); self.assertEqual(self.p.backend.volume, 0.2)
        self.clock.t = 3; self.a.tick(); self.assertEqual(self.p.backend.volume, 0.2)
        self.clock.t = 10; self.a.tick(); self.assertEqual(self.p.backend.volume, 0.8)

    def test_disable_by_voice_then_wake_ignored(self):
        self.a.on_wake(); self.a.on_speech('جوزی فعلاً گوش نده')
        self.assertEqual(self.a.state.mode, Mode.DISABLED); self.assertEqual(self.p.speech.calls[-1], 'stop')
        self.a.on_wake(); self.assertEqual(self.a.state.mode, Mode.DISABLED)
        self.a.manual_enable(); self.a.on_wake(manual=True); self.assertEqual(self.a.state.mode, Mode.ACTIVE)

    def test_subtitles_when_audio_files_missing(self):
        self.a.on_wake(); self.a.on_speech('Who created you?')
        subs = [v for k, v in self.ev if k == 'subtitle']
        self.assertIn('Fahim Yaqoobi', subs[-1])


if __name__ == '__main__':
    unittest.main()

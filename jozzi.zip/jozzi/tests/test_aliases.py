import tempfile, unittest
from platform_android.app_launcher import AppIndex
from platform_android.contacts import Contact, ContactBook
from storage.contacts_aliases import AliasStore


class T(unittest.TestCase):
    def test_alias_crud_persist(self):
        d = tempfile.mkdtemp(); a = AliasStore(d)
        a.set('مامان', 'مریم', '0912')
        self.assertEqual(AliasStore(d).resolve('Mother')['name'], 'مریم')   # persisted + synonyms
        a.edit('Mom', 'مریم جان', with_synonyms=False)
        self.assertEqual(a.resolve('mom')['name'], 'مریم جان')
        self.assertEqual(a.resolve('مامان')['name'], 'مریم')
        a.delete('mom'); self.assertIsNone(a.resolve('mom'))

    def test_contact_search_ranking(self):
        b = ContactBook([Contact('علی رضایی', ['1']), Contact('رضا', ['2']), Contact('Ali Karimi', ['3'])])
        self.assertEqual([c.name for c in b.search('رضا')], ['رضا'])
        self.assertEqual([c.name for c in b.search('ali')], ['Ali Karimi'])
        self.assertEqual([c.name for c in ContactBook([Contact('علي', ['1'])]).search('علی')], ['علي'])

    def test_app_aliases(self):
        i = AppIndex([('Claude', 'a.b'), ('Google Chrome', 'c.d'), ('تلگرام', 'e.f')])
        self.assertEqual(i.find('کلاد').package, 'a.b')
        self.assertEqual(i.find('کروم').package, 'c.d')
        self.assertEqual(i.find('تلگرام').package, 'e.f')
        self.assertEqual(i.find('تنظیمات').package, 'special:settings')
        self.assertEqual(i.find('Open Phone'.replace('Open ', '')).package, 'special:dial')
        self.assertIsNone(i.find('ناموجود'))


if __name__ == '__main__':
    unittest.main()

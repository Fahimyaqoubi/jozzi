import unittest
from datetime import datetime
from core.time_parser import parse_time, detect_period, to_24h


def at(h, m=0, s=0): return datetime(2026, 11, 10, h, m, s)


class T(unittest.TestCase):
    def rel(self, text, now, exp):
        r = parse_time(text, now)
        self.assertTrue(r.relative, text)
        self.assertEqual((r.hour, r.minute), exp, text)

    def test_relative_spec_example(self):
        self.rel('چهل دقیقه دیگه آلارم بذار', at(14, 0), (14, 40))
        self.rel('Set an alarm in 40 minutes', at(14, 0), (14, 40))

    def test_relative_variants(self):
        self.rel('نیم ساعت دیگه بیدارم کن', at(10, 15), (10, 45))
        self.rel('یک ساعت و نیم دیگه آلارم بذار', at(10, 0), (11, 30))
        self.rel('in an hour', at(9, 5), (10, 5))
        self.rel('in half an hour', at(9, 5), (9, 35))
        self.rel('۴۰ دقیقه دیگه', at(14, 0), (14, 40))
        self.rel('in forty five minutes', at(1, 0), (1, 45))

    def test_midnight_transition(self):
        self.rel('چهل دقیقه دیگه', at(23, 50), (0, 30))
        self.rel('in 90 minutes', at(23, 0), (0, 30))

    def test_seconds_never_fire_early(self):
        self.rel('in 10 minutes', at(14, 0, 20), (14, 11))

    def test_absolute_24h(self):
        r = parse_time('ساعت ۱۴:۴۵ آلارم بذار', at(8))
        self.assertEqual((r.hour, r.minute), (14, 45))

    def test_absolute_needs_period(self):
        r = parse_time('شش و نیم', at(8))
        self.assertTrue(r.needs_period)
        self.assertEqual((r.hour12, r.minute), (6, 30))
        self.assertEqual(to_24h(6, detect_period('صبح')), 6)
        self.assertEqual(to_24h(6, detect_period('شب')), 18)

    def test_absolute_with_period(self):
        r = parse_time('Set an alarm for 6:30 AM', at(8)); self.assertEqual((r.hour, r.minute), (6, 30))
        r = parse_time('alarm at 7 pm', at(8)); self.assertEqual((r.hour, r.minute), (19, 0))
        r = parse_time('alarm 6:15 a.m.', at(8)); self.assertEqual((r.hour, r.minute), (6, 15))
        r = parse_time('ساعت شش و ربع صبح', at(8)); self.assertEqual((r.hour, r.minute), (6, 15))
        r = parse_time('دوازده شب', at(8), bare=True); self.assertEqual(r.hour, 0)

    def test_invalid_and_none(self):
        self.assertEqual(parse_time('ساعت 25:99', at(8)).error, 'invalid')
        self.assertIsNone(parse_time('آلارم بذار', at(8)))
        self.assertEqual(parse_time('0 دقیقه دیگه', at(8)).error, 'invalid')

    def test_bare_answer(self):
        r = parse_time('6:30', at(8), bare=True); self.assertTrue(r.needs_period)


if __name__ == '__main__':
    unittest.main()

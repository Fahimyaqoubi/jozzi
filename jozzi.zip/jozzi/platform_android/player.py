class AndroidPlayer:
    """Plays the prerecorded assistant clips with MediaPlayer; transient-duck audio focus."""

    def __init__(self, ctx):
        from jnius import autoclass
        self.ctx, self.ac, self.mp = ctx, autoclass, None

    def play(self, path, on_done):
        from jnius import PythonJavaClass, java_method
        self.stop()
        self.mp = self.ac('android.media.MediaPlayer')()
        self.mp.setDataSource(path)

        class C(PythonJavaClass):
            __javainterfaces__ = ['android/media/MediaPlayer$OnCompletionListener']

            @java_method('(Landroid/media/MediaPlayer;)V')
            def onCompletion(self, mp): on_done()
        self._c = C()
        self.mp.setOnCompletionListener(self._c)
        self.mp.prepare(); self.mp.start()

    def stop(self):
        if self.mp is not None:
            try:
                self.mp.release()
            finally:
                self.mp = None

    release = stop

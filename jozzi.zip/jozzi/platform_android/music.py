"""Music: Playlist + MusicController are pure (unit-tested); AndroidMusicBackend wraps
MediaPlayer + MediaStore + (optional) MediaSession via the small Java bridge."""
import random
from core.text_normalizer import normalize


class Playlist:
    """Holds only (id, title) tuples — never audio data."""

    def __init__(self, rng=None):
        self.rng, self.items, self.order, self.pos = rng or random.Random(), [], [], -1

    def load(self, items):
        self.items = list(items); self.shuffle()

    def shuffle(self):
        self.order = list(range(len(self.items))); self.rng.shuffle(self.order); self.pos = -1

    def current(self):
        return self.items[self.order[self.pos]] if 0 <= self.pos < len(self.order) else None

    def next(self):
        if not self.items:
            return None
        self.pos = (self.pos + 1) % len(self.order)
        return self.current()

    def prev(self):
        if not self.items:
            return None
        self.pos = (self.pos - 1) % len(self.order)
        return self.current()

    def jump_to(self, item):
        self.pos = self.order.index(self.items.index(item))

    def search(self, query):
        q = normalize(query)
        return [it for it in self.items if q and q in normalize(it[1])]


class MusicController:
    DUCK = 0.2

    def __init__(self, backend, playlist=None):
        self.b, self.pl, self.vol, self._loaded, self._paused_by_user = backend, playlist or Playlist(), 0.8, False, False

    def _ensure(self):
        if not self._loaded:
            self.pl.load(self.b.load_library()); self._loaded = True
        return bool(self.pl.items)

    def refresh(self):
        self._loaded = False

    def _play(self, item):
        if item is None:
            return None
        self.b.start(item); self.b.set_volume(self.vol); self._paused_by_user = False
        return item[1]

    def play_random(self):
        if not self._ensure():
            return None
        self.pl.shuffle()
        return self._play(self.pl.next())

    def play_named(self, q):
        if not self._ensure():
            return None
        hits = self.pl.search(q)
        if not hits:
            return None
        self.pl.jump_to(hits[0])
        return self._play(hits[0])

    def next(self):
        return self._play(self.pl.next()) if self._ensure() else None

    def prev(self):
        return self._play(self.pl.prev()) if self._ensure() else None

    def pause(self):
        if not self.b.is_playing():
            return False
        self.b.pause(); self._paused_by_user = True
        return True

    def resume(self):
        if self.b.is_playing() or not self.pl.current():
            return False
        self.b.resume(); self._paused_by_user = False
        return True

    def stop(self):
        if not (self.b.is_playing() or self._paused_by_user):
            return False
        self.b.stop(); self._paused_by_user = False
        return True

    def change_volume(self, delta):
        self.vol = max(0.05, min(1.0, self.vol + delta)); self.b.set_volume(self.vol)
        return self.vol

    def duck(self, on):
        """Lower volume during an assistant interaction; restore afterwards. A track the
        user paused/stopped is never restarted by this."""
        if self.b.is_playing():
            self.b.set_volume(self.DUCK if on else self.vol)
        elif not on:
            self.b.set_volume(self.vol)

    def title(self):
        c = self.pl.current()
        return c[1] if c else ''


class AndroidMusicBackend:
    def __init__(self, ctx):
        from jnius import autoclass
        self.ctx, self.mp, self._ac = ctx, None, autoclass
        self.on_track_end = None            # set by controller owner (auto-advance)
        self.bridge = self._make_bridge()

    def _make_bridge(self):
        try:                                 # optional: lock-screen / headset controls
            from jnius import PythonJavaClass, java_method

            outer = self

            class L(PythonJavaClass):
                __javainterfaces__ = ['org/jozzi/MediaSessionBridge$Listener']
                __javacontext__ = 'app'

                @java_method('(Ljava/lang/String;)V')
                def onCommand(self, cmd):
                    if outer.on_command:
                        outer.on_command(cmd)
            self._listener = L()
            self.on_command = None
            return self._ac('org.jozzi.MediaSessionBridge')(self.ctx, self._listener)
        except Exception:
            self.on_command = None
            return None

    def load_library(self):
        MS = self._ac('android.provider.MediaStore$Audio$Media')
        cur = self.ctx.getContentResolver().query(
            MS.EXTERNAL_CONTENT_URI, [MS._ID, MS.TITLE], MS.IS_MUSIC + ' != 0', None, MS.TITLE + ' ASC')
        out = []
        try:
            while cur.moveToNext():
                out.append((cur.getLong(0), cur.getString(1) or ''))
        finally:
            cur.close()
        return out

    def _release(self):
        if self.mp is not None:
            try:
                self.mp.release()
            finally:
                self.mp = None

    def start(self, item):
        MS = self._ac('android.provider.MediaStore$Audio$Media')
        ContentUris = self._ac('android.content.ContentUris')
        MediaPlayer = self._ac('android.media.MediaPlayer')
        self._release()
        uri = ContentUris.withAppendedId(MS.EXTERNAL_CONTENT_URI, item[0])
        self.mp = MediaPlayer()
        self.mp.setDataSource(self.ctx, uri)
        self.mp.prepare()
        if self.on_track_end:
            from jnius import PythonJavaClass, java_method
            cb = self.on_track_end

            class C(PythonJavaClass):
                __javainterfaces__ = ['android/media/MediaPlayer$OnCompletionListener']

                @java_method('(Landroid/media/MediaPlayer;)V')
                def onCompletion(self, mp):
                    cb()
            self._c = C(); self.mp.setOnCompletionListener(self._c)
        self.mp.start()
        if self.bridge:
            self.bridge.setTitle(item[1]); self.bridge.setState(3)

    def pause(self):
        self.mp and self.mp.pause()
        self.bridge and self.bridge.setState(2)

    def resume(self):
        self.mp and self.mp.start()
        self.bridge and self.bridge.setState(3)

    def stop(self):
        self._release()
        self.bridge and self.bridge.setState(1)

    def set_volume(self, v):
        self.mp and self.mp.setVolume(float(v), float(v))

    def is_playing(self):
        try:
            return bool(self.mp and self.mp.isPlaying())
        except Exception:
            return False

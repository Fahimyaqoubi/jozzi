"""Offline speech via Vosk (vosk-android AAR). Never falls back to an online recogniser.
Models: assets/models/<lang>/ (see README). One mic stream; STANDBY uses a grammar that only
knows the wake phrases (cheap), ACTIVE uses the full small model."""
import json, os
from .wake_word import WAKE_GRAMMAR, is_wake

RATE = 16000.0


class SpeechEngine:
    def __init__(self, models_root, on_wake=None, on_text=None, on_status=None):
        self.root, self.on_wake, self.on_text = models_root, on_wake, on_text
        self.on_status = on_status or (lambda s: None)
        self.models, self.svc, self.mode = {}, None, None
        self._listener = None

    def available(self):
        return {l: os.path.isdir(os.path.join(self.root, l)) for l in ('fa', 'en')}

    def _model(self, lang):
        if lang not in self.models:
            from jnius import autoclass
            path = os.path.join(self.root, lang)
            if not os.path.isdir(path):
                self.on_status(f'offline_model_missing:{lang}')   # reported, never silently online
                return None
            self.models[lang] = autoclass('org.vosk.Model')(path)
        return self.models[lang]

    def _make_listener(self):
        from jnius import PythonJavaClass, java_method
        eng = self

        class L(PythonJavaClass):
            __javainterfaces__ = ['org/vosk/android/RecognitionListener']
            __javacontext__ = 'app'

            @java_method('(Ljava/lang/String;)V')
            def onPartialResult(self, h): pass

            @java_method('(Ljava/lang/String;)V')
            def onResult(self, h): eng._result(h)

            @java_method('(Ljava/lang/String;)V')
            def onFinalResult(self, h): eng._result(h)

            @java_method('(Ljava/lang/Exception;)V')
            def onError(self, e): eng.on_status('speech_error')

            @java_method('()V')
            def onTimeout(self): pass
        return L()

    def _result(self, hyp):
        try:
            t = json.loads(hyp).get('text', '').strip()
        except ValueError:
            return
        if not t:
            return
        if self.mode == 'wake':
            if is_wake(t) and self.on_wake:
                self.on_wake()
        elif self.on_text:
            self.on_text(t)

    def _start(self, lang, grammar):
        self._stop_service()
        model = self._model(lang)
        if model is None:
            return False
        from jnius import autoclass
        Rec, Svc = autoclass('org.vosk.Recognizer'), autoclass('org.vosk.android.SpeechService')
        rec = Rec(model, RATE, json.dumps(grammar, ensure_ascii=False)) if grammar else Rec(model, RATE)
        self.svc = Svc(rec, RATE)
        self._listener = self._make_listener()
        self.svc.startListening(self._listener)
        return True

    def start_wake(self):
        self.mode = 'wake'
        lang = 'fa' if self.available()['fa'] else 'en'
        return self._start(lang, WAKE_GRAMMAR)

    def start_command(self, lang='fa'):
        self.mode = 'command'
        return self._start(lang, None)

    def pause(self):
        self.svc and self.svc.setPause(True)       # don't transcribe our own voice

    def resume(self):
        self.svc and self.svc.setPause(False)

    def _stop_service(self):
        if self.svc:
            try:
                self.svc.stop(); self.svc.shutdown()
            finally:
                self.svc = None

    def stop(self):
        self.mode = None; self._stop_service()

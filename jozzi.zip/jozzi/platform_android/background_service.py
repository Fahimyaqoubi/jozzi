"""Starts/stops the foreground service (service.py, declared in buildozer.spec).
Android 14 requires RECORD_AUDIO to be granted and the app visible when the service starts."""
from config import PACKAGE


def start_service():
    from jnius import autoclass
    activity = autoclass('org.kivy.android.PythonActivity').mActivity
    svc = autoclass(PACKAGE + '.ServiceJozzi')
    svc.start(activity, '')                  # VERIFY on p4a version: signature may add icon/title args
    return True


def stop_service():
    from jnius import autoclass
    activity = autoclass('org.kivy.android.PythonActivity').mActivity
    autoclass(PACKAGE + '.ServiceJozzi').stop(activity)


def request_permissions(callback=None):
    from android.permissions import request_permissions as rp, Permission
    rp([Permission.RECORD_AUDIO, 'android.permission.POST_NOTIFICATIONS'], callback)


def request_optional(kind, callback=None):
    from android.permissions import request_permissions as rp, Permission
    perms = {'contacts': [Permission.READ_CONTACTS],
             'audio': ['android.permission.READ_MEDIA_AUDIO', Permission.READ_EXTERNAL_STORAGE]}[kind]
    rp(perms, callback)

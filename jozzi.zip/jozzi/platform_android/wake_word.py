"""Wake-word matching (pure). The audio-level detector is the grammar-restricted Vosk
recognizer in speech.py; this decides whether its output counts as the wake word."""
import re
from core.text_normalizer import normalize

WAKE_GRAMMAR = ["جوزی", "هی جوزی", "[unk]"]       # restricts the decoder to 2 phrases + garbage
_PAT = re.compile(r'(?:\bجوزی\b|\bjozzi\b|\bjozi\b|\bjoozi\b|\bhey jozzi\b)')


def is_wake(text: str) -> bool:
    return bool(_PAT.search(normalize(text)))

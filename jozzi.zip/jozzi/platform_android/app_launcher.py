"""App discovery via PackageManager (queries <intent> MAIN/LAUNCHER, no QUERY_ALL_PACKAGES)."""
from dataclasses import dataclass
from core.text_normalizer import normalize

BUILTIN = {'کلاد': 'claude', 'کروم': 'chrome', 'تلگرام': 'telegram', 'تلفن': 'phone', 'تنظیمات': 'settings',
           'واتساپ': 'whatsapp', 'دوربین': 'camera', 'اینستاگرام': 'instagram', 'یوتیوب': 'youtube',
           'گالری': 'gallery', 'ساعت': 'clock', 'مرورگر': 'browser', 'ماشین حساب': 'calculator',
           'ایتا': 'eitaa', 'بله': 'bale', 'مخاطبین': 'contacts', 'پیام ها': 'messages'}
SPECIAL = {'phone': 'special:dial', 'settings': 'special:settings'}


@dataclass
class App:
    label: str
    package: str


class AppIndex:
    def __init__(self, apps=None, user_aliases=None):
        self.set_apps(apps or []); self.user = {normalize(k): normalize(v) for k, v in (user_aliases or {}).items()}

    def set_apps(self, apps):
        self.apps = [App(l, p) for l, p in apps]
        self._norm = [(normalize(a.label), a) for a in self.apps]

    def find(self, query):
        q = normalize(query)
        for pre in ('برنامه ', 'اپ ', 'اپلیکیشن ', 'app '):
            if q.startswith(pre):
                q = q[len(pre):]
        mapped = self.user.get(q) or BUILTIN.get(q)
        if (mapped or q) in SPECIAL:
            key = mapped or q
            return App(key.capitalize(), SPECIAL[key])
        for cand in (q, mapped):                 # try the spoken name first (localized labels), then the alias
            if not cand:
                continue
            for test in (lambda n: n == cand, lambda n: n.startswith(cand), lambda n: cand in n,
                         lambda n: all(t in n for t in cand.split())):
                hits = [a for n, a in self._norm if test(n)]
                if hits:
                    return hits[0]
        return None


def scan_apps(ctx):
    from jnius import autoclass
    Intent = autoclass('android.content.Intent')
    i = Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER)
    pm = ctx.getPackageManager()
    out = []
    it = pm.queryIntentActivities(i, 0).iterator()
    while it.hasNext():
        ri = it.next()
        out.append((str(ri.loadLabel(pm)), str(ri.activityInfo.packageName)))
    return out


class AndroidLauncher:
    def __init__(self, ctx, settings=None):
        self.ctx, self.settings = ctx, settings
        self.index = AppIndex(user_aliases=settings.get('app_aliases', {}) if settings else None)
        self.refresh()

    def refresh(self):
        self.index.set_apps(scan_apps(self.ctx))

    def find(self, q):
        return self.index.find(q)

    def launch(self, app):
        from jnius import autoclass
        from platform_android.intents import start
        Intent = autoclass('android.content.Intent')
        try:
            if app.package == 'special:dial':
                i = Intent(Intent.ACTION_DIAL)
            elif app.package == 'special:settings':
                i = Intent(autoclass('android.provider.Settings').ACTION_SETTINGS)
            else:
                i = self.ctx.getPackageManager().getLaunchIntentForPackage(app.package)
                if i is None:
                    return False
            return start(self.ctx, i)
        except Exception:
            return False

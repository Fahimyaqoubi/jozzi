from types import SimpleNamespace


def build_platform(settings, models_root):
    """Real Android implementation of the platform interface used by core/."""
    from jnius import autoclass
    ctx = autoclass('org.kivy.android.PythonService').mService      # service process context
    from .alarms import AndroidAlarms
    from .app_launcher import AndroidLauncher
    from .calling import AndroidCalling
    from .contacts import AndroidContacts
    from .messaging import AndroidMessaging
    from .music import AndroidMusicBackend, MusicController
    from .player import AndroidPlayer
    from .speech import SpeechEngine
    backend = AndroidMusicBackend(ctx)
    music = MusicController(backend)
    backend.on_track_end = music.next
    backend.on_command = lambda c: {'play': music.resume, 'pause': music.pause, 'stop': music.stop,
                                    'next': music.next, 'prev': music.prev}.get(c, lambda: None)()
    return SimpleNamespace(
        ctx=ctx, contacts=AndroidContacts(ctx), messaging=AndroidMessaging(ctx), calling=AndroidCalling(ctx),
        launcher=AndroidLauncher(ctx, settings), music=music, alarms=AndroidAlarms(ctx),
        player=AndroidPlayer(ctx), speech=SpeechEngine(models_root))

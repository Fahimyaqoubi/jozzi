from urllib.parse import quote
from platform_android.intents import start


class AndroidMessaging:
    """Opens a messaging UI with the text prefilled. Never sends silently."""

    def __init__(self, ctx):
        self.ctx = ctx

    def open(self, number, text, app=None):
        from jnius import autoclass
        Intent, Uri = autoclass('android.content.Intent'), autoclass('android.net.Uri')
        digits = ''.join(ch for ch in number if ch.isdigit() or ch == '+')
        try:
            if app == 'whatsapp':
                i = Intent(Intent.ACTION_VIEW, Uri.parse(f"https://wa.me/{digits.lstrip('+')}?text={quote(text)}"))
                i.setPackage('com.whatsapp')
            elif app == 'telegram':        # Telegram cannot prefill a recipient: user picks the chat
                i = Intent(Intent.ACTION_SEND); i.setType('text/plain')
                i.putExtra(Intent.EXTRA_TEXT, text); i.setPackage('org.telegram.messenger')
            else:
                i = Intent(Intent.ACTION_SENDTO, Uri.parse('smsto:' + digits))
                i.putExtra('sms_body', text)
            return start(self.ctx, i)
        except Exception:
            return False

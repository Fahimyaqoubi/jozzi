"""Contact lookup. ContactBook is pure Python (unit-tested); read_contacts() uses Pyjnius."""
from dataclasses import dataclass, field
from core.text_normalizer import normalize


@dataclass
class Contact:
    name: str
    numbers: list = field(default_factory=list)
    id: str = ''


class ContactBook:
    def __init__(self, contacts=None):
        self.set(contacts or [])

    def set(self, contacts):
        self._items = [(normalize(c.name), c) for c in contacts]

    def search(self, query):
        q = normalize(query)
        if not q:
            return []
        exact = [c for n, c in self._items if n == q]
        if exact:
            return exact
        starts = [c for n, c in self._items if n.startswith(q)]
        if starts:
            return starts
        qt = q.split()
        toks = [c for n, c in self._items if all(t in n.split() for t in qt)]
        return toks or [c for n, c in self._items if q in n]


def read_contacts(ctx):
    """Reads name+numbers via ContactsContract. Never logs or uploads them."""
    from jnius import autoclass
    Phone = autoclass('android.provider.ContactsContract$CommonDataKinds$Phone')
    cur = ctx.getContentResolver().query(
        Phone.CONTENT_URI, [Phone.CONTACT_ID, Phone.DISPLAY_NAME, Phone.NUMBER], None, None,
        Phone.DISPLAY_NAME + ' ASC')
    by_id = {}
    try:
        while cur.moveToNext():
            cid, name, num = cur.getString(0), cur.getString(1), cur.getString(2)
            if not name or not num:
                continue
            c = by_id.setdefault(cid, Contact(name, [], cid))
            if num not in c.numbers:
                c.numbers.append(num)
    finally:
        cur.close()
    return list(by_id.values())


class AndroidContacts:
    def __init__(self, ctx):
        self.ctx, self.book, self._loaded = ctx, ContactBook(), False

    def refresh(self):
        self.book.set(read_contacts(self.ctx)); self._loaded = True

    def search(self, q):
        if not self._loaded:
            self.refresh()
        return self.book.search(q)

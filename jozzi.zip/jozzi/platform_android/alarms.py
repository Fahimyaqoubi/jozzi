from platform_android.intents import start


class AndroidAlarms:
    """AlarmClock.ACTION_SET_ALARM (needs SET_ALARM permission). The intent has no result
    callback, so we can only confirm a handler exists and accepted the dispatch."""

    def __init__(self, ctx):
        self.ctx = ctx

    def set_alarm(self, hour, minute, label='Jozzi'):
        from jnius import autoclass
        AC, Intent = autoclass('android.provider.AlarmClock'), autoclass('android.content.Intent')
        try:
            i = Intent(AC.ACTION_SET_ALARM)
            i.putExtra(AC.EXTRA_HOUR, int(hour)); i.putExtra(AC.EXTRA_MINUTES, int(minute))
            i.putExtra(AC.EXTRA_MESSAGE, label); i.putExtra(AC.EXTRA_SKIP_UI, True)
            return start(self.ctx, i)
        except Exception:
            return False

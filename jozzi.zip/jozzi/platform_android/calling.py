from platform_android.intents import start


class AndroidCalling:
    """ACTION_DIAL only: no CALL_PHONE permission needed, user presses the call button."""

    def __init__(self, ctx):
        self.ctx = ctx

    def dial(self, number):
        from jnius import autoclass
        Intent, Uri = autoclass('android.content.Intent'), autoclass('android.net.Uri')
        try:
            digits = ''.join(ch for ch in number if ch.isdigit() or ch == '+')
            return start(self.ctx, Intent(Intent.ACTION_DIAL, Uri.parse('tel:' + digits)))
        except Exception:
            return False

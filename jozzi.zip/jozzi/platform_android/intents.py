"""Shared helper to start activities. From a background service Android 10+ may silently
block the launch (background-activity-start limits) — see README 'Android limits'."""


def start(ctx, intent):
    from jnius import autoclass
    Intent = autoclass('android.content.Intent')
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    if intent.resolveActivity(ctx.getPackageManager()) is None:
        return False                      # nothing can handle it: report failure honestly
    ctx.startActivity(intent)
    return True

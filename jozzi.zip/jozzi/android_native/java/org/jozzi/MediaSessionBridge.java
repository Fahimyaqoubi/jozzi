package org.jozzi;

import android.content.Context;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;

/** MediaSession.Callback is an abstract class, which Pyjnius cannot subclass; this bridge forwards to a Python-implemented Listener. */
public class MediaSessionBridge {
    public interface Listener { void onCommand(String cmd); }

    private final MediaSession session;

    public MediaSessionBridge(Context ctx, final Listener l) {
        session = new MediaSession(ctx, "Jozzi");
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { l.onCommand("play"); }
            @Override public void onPause() { l.onCommand("pause"); }
            @Override public void onStop() { l.onCommand("stop"); }
            @Override public void onSkipToNext() { l.onCommand("next"); }
            @Override public void onSkipToPrevious() { l.onCommand("prev"); }
        });
        session.setActive(true);
    }

    /** state: PlaybackState.STATE_* (1 stopped, 2 paused, 3 playing) */
    public void setState(int state) {
        long actions = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE | PlaybackState.ACTION_STOP
                | PlaybackState.ACTION_SKIP_TO_NEXT | PlaybackState.ACTION_SKIP_TO_PREVIOUS;
        session.setPlaybackState(new PlaybackState.Builder().setActions(actions)
                .setState(state, 0, state == 3 ? 1f : 0f).build());
    }

    public void setTitle(String title) {
        session.setMetadata(new MediaMetadata.Builder().putString(MediaMetadata.METADATA_KEY_TITLE, title).build());
    }

    public void release() { session.setActive(false); session.release(); }
}

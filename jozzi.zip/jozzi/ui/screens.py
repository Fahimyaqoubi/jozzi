from kivy.metrics import dp, sp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.screenmanager import Screen
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput
from .orb import Orb
from .subtitles import font, shape

BG = (0.03, 0.04, 0.08, 1)


def lbl(text='', size=16, color=(1, 1, 1, .9), **kw):
    l = Label(text=shape(text), font_size=sp(size), color=color, halign='center', valign='middle', **kw)
    f = font()
    if f:
        l.font_name = f
    l.bind(size=lambda w, s: setattr(w, 'text_size', (s[0], None)))
    return l


def set_text(label, text):
    label.text = shape(text)


class MainScreen(Screen):
    def __init__(self, on_activate, on_disable, on_settings, on_typed, **kw):
        super().__init__(**kw)
        root = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(6))
        self.status = lbl('', 12, (1, 1, 1, .55), size_hint_y=None, height=dp(28))
        self.orb = Orb()
        self.name = lbl('Jozzi', 26, size_hint_y=None, height=dp(40))
        self.state = lbl('', 14, (.6, .8, 1, 1), size_hint_y=None, height=dp(24))
        self.heard = lbl('', 15, (1, 1, 1, .6), size_hint_y=None, height=dp(48))
        self.sub = lbl('', 18, size_hint_y=None, height=dp(90))
        self.music = lbl('', 12, (1, 1, 1, .5), size_hint_y=None, height=dp(24))
        row = BoxLayout(size_hint_y=None, height=dp(48), spacing=dp(8))
        for t, cb in (('Activate', on_activate), ('Disable', on_disable), ('Settings', on_settings)):
            b = Button(text=t); b.bind(on_release=lambda *_a, cb=cb: cb()); row.add_widget(b)
        self.typed = TextInput(hint_text='type a command (debug / no mic)', multiline=False,
                               size_hint_y=None, height=dp(40), font_name=font() or 'Roboto')
        self.typed.bind(on_text_validate=lambda w: (on_typed(w.text), setattr(w, 'text', '')))
        for w in (self.status, self.orb, self.name, self.state, self.heard, self.sub, self.music, row, self.typed):
            root.add_widget(w)
        self.add_widget(root)


class SettingsScreen(Screen):
    def __init__(self, settings, aliases, on_back, on_refresh, on_perm, **kw):
        super().__init__(**kw)
        self.settings, self.aliases = settings, aliases
        self.root_box = BoxLayout(orientation='vertical', padding=dp(12), spacing=dp(8))
        sp_ = Spinner(text=settings.get('recognition_language', 'fa'), values=('fa', 'en'),
                      size_hint_y=None, height=dp(44))
        sp_.bind(text=lambda w, v: settings.set('recognition_language', v))
        self.alias_in, self.contact_in = (TextInput(hint_text=h, multiline=False, size_hint_y=None,
                                                    height=dp(40), font_name=font() or 'Roboto')
                                          for h in ('alias (مامان / Mom)', 'exact contact name'))
        add = Button(text='Save alias', size_hint_y=None, height=dp(44)); add.bind(on_release=self._add)
        self.alias_list = lbl('', 13, size_hint_y=1)
        btns = BoxLayout(size_hint_y=None, height=dp(44), spacing=dp(6))
        for t, cb in (('Refresh apps/contacts', on_refresh), ('Contacts perm', lambda: on_perm('contacts')),
                      ('Audio perm', lambda: on_perm('audio')), ('Back', on_back)):
            b = Button(text=t); b.bind(on_release=lambda *_a, cb=cb: cb()); btns.add_widget(b)
        for w in (lbl('Recognition language', 14, size_hint_y=None, height=dp(24)), sp_, self.alias_in,
                  self.contact_in, add, self.alias_list, btns):
            self.root_box.add_widget(w)
        self.add_widget(self.root_box); self._show()

    def _add(self, *_):
        if self.alias_in.text.strip() and self.contact_in.text.strip():
            self.aliases.set(self.alias_in.text, self.contact_in.text.strip())
            self.alias_in.text = self.contact_in.text = ''; self._show()

    def _show(self):
        seen = {}
        for k, v in self.aliases.all().items():
            seen.setdefault(v['name'], []).append(k)
        set_text(self.alias_list, '\n'.join(f"{', '.join(k)} → {n}" for n, k in seen.items()) or '—')

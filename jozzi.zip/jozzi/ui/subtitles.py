import os, re
_AR = re.compile(r'[\u0600-\u06FF]')
FONTS = ['assets/fonts/Vazirmatn-Regular.ttf', '/system/fonts/NotoNaskhArabic-Regular.ttf',
         '/system/fonts/DroidNaskh-Regular.ttf']


def font():
    here = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for f in FONTS:
        p = f if os.path.isabs(f) else os.path.join(here, f)
        if os.path.isfile(p):
            return p
    return None            # Persian glyphs will be missing: add Vazirmatn (OFL) to assets/fonts


def shape(text: str) -> str:
    """Shape + reorder Persian for SDL text rendering (RTL)."""
    if not _AR.search(text):
        return text
    try:
        import arabic_reshaper
        from bidi.algorithm import get_display
        return '\n'.join(get_display(arabic_reshaper.reshape(l)) for l in text.split('\n'))
    except Exception:
        return text

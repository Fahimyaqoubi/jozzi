# per-state look of the orb: colour, pulse speed/amplitude, redraw rate (low when idle)
STYLE = {
    'standby':    dict(rgb=(0.25, 0.45, 0.90), speed=0.6, amp=0.04, fps=10, alpha=0.55),
    'listening':  dict(rgb=(0.20, 0.85, 0.90), speed=2.2, amp=0.09, fps=30, alpha=0.90),
    'processing': dict(rgb=(0.70, 0.40, 1.00), speed=4.0, amp=0.06, fps=30, alpha=0.90),
    'speaking':   dict(rgb=(0.30, 0.90, 0.50), speed=3.0, amp=0.12, fps=30, alpha=0.95),
    'success':    dict(rgb=(0.30, 1.00, 0.40), speed=1.5, amp=0.05, fps=24, alpha=0.95),
    'error':      dict(rgb=(1.00, 0.30, 0.30), speed=5.0, amp=0.05, fps=24, alpha=0.95),
    'disabled':   dict(rgb=(0.40, 0.40, 0.45), speed=0.2, amp=0.01, fps=4, alpha=0.35),
}

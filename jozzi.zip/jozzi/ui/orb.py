import math
from kivy.clock import Clock
from kivy.graphics import Color, Ellipse
from kivy.properties import StringProperty
from kivy.uix.widget import Widget
from .animations import STYLE


class Orb(Widget):
    state = StringProperty('standby')

    def __init__(self, **kw):
        super().__init__(**kw)
        self._t, self._ev = 0.0, None
        self.bind(size=lambda *a: self._draw(), pos=lambda *a: self._draw(), state=lambda *a: self._reschedule())
        self._reschedule()

    def _reschedule(self):
        if self._ev:
            self._ev.cancel()
        self._ev = Clock.schedule_interval(self._tick, 1.0 / STYLE[self.state]['fps'])

    def pause(self):                  # call from on_pause: no redraws while backgrounded
        if self._ev:
            self._ev.cancel(); self._ev = None

    def resume(self):
        self._reschedule()

    def _tick(self, dt):
        self._t += dt
        self._draw()

    def _draw(self):
        s = STYLE[self.state]
        r0 = min(self.width, self.height) * 0.28
        pulse = 1 + s['amp'] * math.sin(self._t * s['speed'] * math.pi)
        cx, cy = self.center
        self.canvas.clear()
        with self.canvas:
            for i, (k, a) in enumerate(((2.4, .06), (1.9, .10), (1.5, .16), (1.2, .30), (1.0, 1.0))):
                r = r0 * k * pulse
                Color(*s['rgb'], a * s['alpha'])
                Ellipse(pos=(cx - r, cy - r), size=(2 * r, 2 * r))

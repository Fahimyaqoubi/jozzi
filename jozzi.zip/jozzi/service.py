"""Foreground service entry point (python-for-android). Owns mic, speech, audio, assistant."""
import os, sys, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import OSC_SERVICE_PORT, OSC_UI_PORT
from core.assistant import Assistant
from core.ipc import Channel
from audio.audio_manager import AudioManager
from storage.contacts_aliases import AliasStore
from storage.settings import Settings


def main():
    root = os.path.dirname(os.path.abspath(__file__))
    settings, aliases = Settings(), AliasStore()
    chan = Channel(OSC_SERVICE_PORT, OSC_UI_PORT)
    from platform_android import build_platform
    plat = build_platform(settings, os.path.join(root, 'assets', 'models'))
    audio = AudioManager(plat.player, os.path.join(root, 'assets', 'audio'))
    asst = Assistant(plat, audio, aliases, settings, emit=chan.send)
    plat.speech.on_wake = asst.on_wake
    plat.speech.on_text = asst.on_speech
    plat.speech.on_status = lambda s: chan.send('status', s)
    chan.bind('activate', lambda *_: asst.on_wake(manual=True))
    chan.bind('disable', lambda *_: asst.manual_disable())
    chan.bind('enable', lambda *_: asst.manual_enable())
    chan.bind('text', lambda t, *_: asst.on_speech(t) if asst.state.mode.value == 'active' else None)
    chan.bind('refresh', lambda *_: (plat.launcher.refresh(), plat.contacts.refresh(), plat.music.refresh()))
    chan.send('status', 'models:' + ','.join(k for k, v in plat.speech.available().items() if v))
    asst.start()
    while True:                       # 1 Hz tick only: timeout + ducking; no polling elsewhere
        time.sleep(1)
        asst.tick()


if __name__ == '__main__':
    main()

# Store descriptions (draft)

## فارسی
**جوزی – دستیار صوتی شخصی آفلاین**
با گفتن «جوزی» دستیار شما بیدار می‌شود؛ بدون اینترنت و بدون ارسال صدا یا مخاطبین به هیچ سروری.
• ارسال پیام، تماس، باز کردن برنامه‌ها، پخش موسیقی موجود در گوشی، تنظیم آلارم
• گفتگوی چندمرحله‌ای: اگر اطلاعات ناقص باشد از شما می‌پرسد
• فارسی و انگلیسی، با صدای ضبط‌شده و زیرنویس
• سبک و کم‌مصرف، با اعلان دائمی و میکروفون فقط در زمان مجاز
سازنده: فهیم یعقوبی

## English
**Jozzi – Offline Personal Voice Assistant**
Say “Hey Jozzi” and your assistant wakes up — offline, with no audio or contacts ever leaving your phone.
• Messages, calls, open apps, play your local music, set alarms
• Multi-step conversations: it asks when something is missing
• Persian & English, prerecorded voice plus subtitles
• Lightweight, with a visible notification while listening
Developer: Fahim Yaqoobi

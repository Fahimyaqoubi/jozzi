"""DEV-TIME ONLY (needs internet + ffmpeg on the developer machine; the app itself never does).
Creates assets/audio/{fa,en}/<key>.ogg from the manifest with one neural voice per language,
then normalises loudness, trims silence and encodes small mono Opus/Vorbis files.
    pip install edge-tts ; python tools/generate_audio.py
Replace with real studio recordings any time: just keep the same file names."""
import asyncio, os, subprocess, sys, tempfile
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
from core.response_manager import MANIFEST

VOICES = {'fa': 'fa-IR-DilaraNeural', 'en': 'en-US-JennyNeural'}   # check `edge-tts --list-voices`


async def synth(text, voice, out):
    import edge_tts
    await edge_tts.Communicate(text, voice).save(out)


def main():
    for lang, idx in (('fa', 1), ('en', 2)):
        os.makedirs(os.path.join(ROOT, 'assets', 'audio', lang), exist_ok=True)
        for row in MANIFEST:
            key, text = row[0], row[idx]
            dst = os.path.join(ROOT, 'assets', 'audio', lang, key + '.ogg')
            with tempfile.NamedTemporaryFile(suffix='.mp3', delete=False) as t:
                tmp = t.name
            asyncio.run(synth(text, VOICES[lang], tmp))
            subprocess.run(['ffmpeg', '-y', '-loglevel', 'error', '-i', tmp, '-af',
                            'silenceremove=start_periods=1:start_threshold=-50dB,areverse,'
                            'silenceremove=start_periods=1:start_threshold=-50dB,areverse,'
                            'loudnorm=I=-18:TP=-2:LRA=7', '-ac', '1', '-ar', '24000', '-c:a', 'libvorbis',
                            '-q:a', '3', dst], check=True)
            os.unlink(tmp)
            print(lang, key)


if __name__ == '__main__':
    main()

"""Pure-python 512x512 orb icon (no PIL)."""
import math, os, struct, zlib
N = 512
rows = []
for y in range(N):
    row = bytearray([0])
    for x in range(N):
        d = math.hypot(x - N / 2, y - N / 2) / (N / 2)
        core = max(0.0, 1 - d / 0.55)
        glow = max(0.0, 1 - d) ** 2.2
        r = int(8 + 60 * glow + 160 * core ** 2)
        g = int(12 + 150 * glow + 200 * core)
        b = int(28 + 230 * glow + 120 * core)
        row += bytes((min(r, 255), min(g, 255), min(b, 255)))
    rows.append(bytes(row))
def chunk(t, d):
    c = struct.pack('>I', len(d)) + t + d
    return c + struct.pack('>I', zlib.crc32(t + d) & 0xffffffff)
png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>IIBBBBB', N, N, 8, 2, 0, 0, 0)) + \
      chunk(b'IDAT', zlib.compress(b''.join(rows), 9)) + chunk(b'IEND', b'')
out = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'assets', 'icons', 'icon.png')
open(out, 'wb').write(png); print('wrote', out, len(png), 'bytes')

"""Writes tools/recording_manifest.csv from core.response_manager.MANIFEST."""
import csv, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from core.response_manager import MANIFEST

with open(os.path.join(os.path.dirname(__file__), 'recording_manifest.csv'), 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.writer(f)
    w.writerow(['n', 'key', 'fa_file', 'fa_text', 'en_file', 'en_text'])
    for i, (k, fa, en) in enumerate(MANIFEST, 1):
        w.writerow([i, k, f'assets/audio/fa/{k}.ogg', fa, f'assets/audio/en/{k}.ogg', en])
print(len(MANIFEST), 'clips per language')

import time
from dataclasses import dataclass, field
from typing import Optional
from config import PENDING_TIMEOUT_S


@dataclass
class Choice:
    name: str
    number: str


@dataclass
class Pending:
    kind: str                 # message | call | alarm
    slots: dict
    awaiting: str             # text | contact | contact_choice | confirm | time | period
    lang: str
    created: float = 0.0
    candidates: Optional[list] = None


class ConversationManager:
    """Holds the single pending multi-turn operation (slot filling state)."""

    def __init__(self, clock=time.monotonic, timeout=PENDING_TIMEOUT_S):
        self.clock, self.timeout, self.pending = clock, timeout, None

    def begin(self, kind, slots, awaiting, lang, candidates=None):
        self.pending = Pending(kind, slots, awaiting, lang, self.clock(), candidates)
        return self.pending

    def refresh(self):
        if self.pending:
            self.pending.created = self.clock()

    def clear(self):
        self.pending = None

    def check_timeout(self) -> bool:
        if self.pending and self.clock() - self.pending.created >= self.timeout:
            self.pending = None
            return True
        return False

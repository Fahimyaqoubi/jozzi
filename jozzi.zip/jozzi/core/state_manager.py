import time
from enum import Enum
from config import ACTIVE_TIMEOUT_S


class Mode(str, Enum):
    STANDBY = 'standby'    # only the wake-word detector runs
    ACTIVE = 'active'      # commands accepted without repeating the wake word
    DISABLED = 'disabled'  # not listening at all (user disabled)


class StateManager:
    def __init__(self, clock=time.monotonic, timeout=ACTIVE_TIMEOUT_S, on_change=None):
        self.clock, self.timeout, self.on_change = clock, timeout, on_change
        self.mode, self._last = Mode.STANDBY, 0.0

    def _set(self, mode):
        if mode is not self.mode:
            self.mode = mode
            if self.on_change:
                self.on_change(mode)

    def activate(self) -> bool:            # wake word: ignored while DISABLED
        if self.mode is Mode.DISABLED:
            return False
        self._last = self.clock(); self._set(Mode.ACTIVE)
        return True

    def force_activate(self):              # manual activation from UI/notification
        self.mode = Mode.STANDBY if self.mode is Mode.DISABLED else self.mode
        return self.activate()

    def touch(self):                       # every received command resets the timeout
        if self.mode is Mode.ACTIVE:
            self._last = self.clock()

    def standby(self): self._set(Mode.STANDBY)
    def disable(self): self._set(Mode.DISABLED)
    def enable(self):
        if self.mode is Mode.DISABLED:
            self._set(Mode.STANDBY)

    def tick(self) -> bool:                # call ~1/s; True when it just timed out
        if self.mode is Mode.ACTIVE and self.clock() - self._last >= self.timeout:
            self._set(Mode.STANDBY)
            return True
        return False

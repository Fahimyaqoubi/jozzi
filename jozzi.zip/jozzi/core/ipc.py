"""UI <-> service messaging over localhost OSC (oscpy, pure Python). Text only, never audio."""


class Channel:
    def __init__(self, listen_port, peer_port):
        from oscpy.server import OSCThreadServer
        from oscpy.client import OSCClient
        self.server = OSCThreadServer(encoding='utf8')
        self.server.listen('127.0.0.1', port=listen_port, default=True)
        self.client = OSCClient('127.0.0.1', peer_port, encoding='utf8')

    def bind(self, name, cb):
        self.server.bind(('/' + name).encode(), lambda *a: cb(*[x.decode() if isinstance(x, bytes) else x for x in a]))

    def send(self, name, value=''):
        self.client.send_message(('/' + name).encode(), [str(value)])

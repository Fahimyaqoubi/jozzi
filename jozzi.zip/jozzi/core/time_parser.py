"""Alarm time parsing (Persian/English, digits or words). Pure functions."""
import re
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Optional
from .text_normalizer import normalize

_FA_U = {'صفر': 0, 'یک': 1, 'یه': 1, 'دو': 2, 'سه': 3, 'چهار': 4, 'پنج': 5, 'شش': 6, 'شیش': 6,
         'هفت': 7, 'هشت': 8, 'نه': 9, 'ده': 10, 'یازده': 11, 'دوازده': 12, 'سیزده': 13,
         'چهارده': 14, 'پانزده': 15, 'شانزده': 16, 'هفده': 17, 'هجده': 18, 'نوزده': 19}
_EN_U = {'zero': 0, 'one': 1, 'two': 2, 'three': 3, 'four': 4, 'five': 5, 'six': 6, 'seven': 7,
         'eight': 8, 'nine': 9, 'ten': 10, 'eleven': 11, 'twelve': 12, 'thirteen': 13,
         'fourteen': 14, 'fifteen': 15, 'sixteen': 16, 'seventeen': 17, 'eighteen': 18,
         'nineteen': 19}
_FA_T = {'بیست': 20, 'سی': 30, 'چهل': 40, 'پنجاه': 50, 'شصت': 60, 'هفتاد': 70, 'هشتاد': 80, 'نود': 90}
_EN_T = {'twenty': 20, 'thirty': 30, 'forty': 40, 'fifty': 50, 'sixty': 60, 'seventy': 70,
         'eighty': 80, 'ninety': 90}
_UNITS = {**_FA_U, **_EN_U}
_TENS = {**_FA_T, **_EN_T}


def words_to_digits(t: str) -> str:
    toks, out, i = t.split(), [], 0
    while i < len(toks):
        w = toks[i]
        if w in _TENS:
            v = _TENS[w]
            if i + 2 < len(toks) and toks[i + 1] == 'و' and 1 <= _UNITS.get(toks[i + 2], 0) <= 9:
                v += _UNITS[toks[i + 2]]; i += 3
            elif w in _EN_T and i + 1 < len(toks) and 1 <= _EN_U.get(toks[i + 1], 0) <= 9:
                v += _EN_U[toks[i + 1]]; i += 2
            else:
                i += 1
            out.append(str(v))
        elif w in _UNITS:
            out.append(str(_UNITS[w])); i += 1
        else:
            out.append(w); i += 1
    return ' '.join(out)


@dataclass
class TimeResult:
    hour: Optional[int] = None       # 24h; None => AM/PM still needed
    minute: int = 0
    relative: bool = False
    hour12: Optional[int] = None
    minutes_from_now: int = 0
    error: str = ''

    @property
    def needs_period(self) -> bool:
        return self.hour is None and not self.error


def _prep(text: str) -> str:
    text = re.sub(r'\b([ap])\.?\s?m\.?(?=\W|$)', r'\1m', text, flags=re.I)   # a.m./p.m.
    return words_to_digits(normalize(text))


def detect_period(text: str) -> Optional[str]:
    t = _prep(text)
    if re.search(r'بعد ?از ?ظهر|عصر|(?<![a-z])(?:pm|afternoon|evening)\b', t):
        return 'pm'
    if re.search(r'(?<![a-z])(?:am|morning)\b|صبح|بامداد|سحر', t):
        return 'am'
    if re.search(r'شب|(?<![a-z])night\b', t):
        return 'night'
    if 'ظهر' in t:
        return 'noon'
    return None


def to_24h(h: int, period: Optional[str]) -> Optional[int]:
    if period == 'am':
        return 0 if h == 12 else h
    if period == 'pm':
        return 12 if h == 12 else h + 12
    if period == 'night':
        return 0 if h == 12 else (h if h <= 5 else h + 12)
    if period == 'noon':
        return 12 if h == 12 else (h + 12 if h <= 5 else h)
    return None


def parse_time(text: str, now: datetime, bare: bool = False) -> Optional[TimeResult]:
    """Relative times use `now` (the real system clock, injected for tests)."""
    t = re.sub(r'\b1\s+ربع', 'ربع', _prep(text))
    rel = bool(re.search(r'دیگه|دیگر|\blater\b|\bin\s+(?:\d+|an?|half|quarter)\b', t))
    if rel:
        mins = None
        m = re.search(r'(\d+)\s*(ساعت|hours?|hrs?|دقیقه|minutes?|mins?)'
                      r'(?:\s*و\s*(نیم|ربع|\d+\s*دقیقه))?', t)
        if m:
            unit = m.group(2)
            mins = int(m.group(1)) * (60 if unit == 'ساعت' or unit.startswith(('hour', 'hr')) else 1)
            ex = m.group(3)
            if ex:
                mins += 30 if ex == 'نیم' else 15 if ex == 'ربع' else int(re.match(r'\d+', ex).group())
        elif re.search(r'نیم ساعت|half an hour|half hour', t):
            mins = 30
        elif re.search(r'ربع|quarter', t):
            mins = 15
        elif re.search(r'\ban? hour\b', t):
            mins = 60
        if not mins or not 0 < mins <= 1440:
            return TimeResult(error='invalid')
        tgt = now + timedelta(minutes=mins)
        if tgt.second or tgt.microsecond:                      # never fire early
            tgt = tgt.replace(second=0, microsecond=0) + timedelta(minutes=1)
        return TimeResult(hour=tgt.hour, minute=tgt.minute, relative=True, minutes_from_now=mins)

    period = detect_period(text)
    h = mi = None
    if (m := re.search(r'(?<!\d)(\d{1,2}):(\d{2})(?!\d)', t)):
        h, mi = int(m[1]), int(m[2])
    elif (m := re.search(r'(?<!\d)(\d{1,2})\s*و\s*(نیم|ربع)', t)):
        h, mi = int(m[1]), (30 if m[2] == 'نیم' else 15)
    elif (m := re.search(r'(?<!\d)(\d{1,2})\s*و\s*(\d{1,2})\s*دقیقه', t)):
        h, mi = int(m[1]), int(m[2])
    elif (m := re.search(r'(?<!\d)(\d{1,2})\s*(?:am|pm)\b', t)):
        h, mi = int(m[1]), 0
    elif (m := re.search(r'(?:ساعت|\bat\b|\bfor\b)\s*(\d{1,2})(?!\d)', t)):
        h, mi = int(m[1]), 0
    elif bare and (m := re.search(r'(?<!\d)(\d{1,2})(?!\d)', t)):
        h, mi = int(m[1]), 0
    else:
        return None
    if h > 23 or mi > 59:
        return TimeResult(error='invalid')
    hour = h if (h > 12 or h == 0) else to_24h(h, period)
    return TimeResult(hour=hour, minute=mi, hour12=h if hour is None else None)

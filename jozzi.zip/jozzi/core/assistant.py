"""Glue: state machine + router + audio + speech. Platform pieces are injected."""
import time
from datetime import datetime
from config import INTERACTION_IDLE_S
from .command_router import CommandRouter
from .response_manager import Response, text as vtext
from .state_manager import StateManager, Mode


class Assistant:
    def __init__(self, platform, audio, aliases, settings, emit=None,
                 clock=time.monotonic, now_fn=datetime.now):
        self.p, self.audio, self.settings, self.clock = platform, audio, settings, clock
        self.emit = emit or (lambda kind, value='': None)
        self.state = StateManager(clock, on_change=self._on_mode)
        self.router = CommandRouter(platform, aliases, now_fn, clock)
        self._ducked, self._last_reply = False, 0.0
        audio.on_busy = lambda: (self.emit('orb', 'speaking'), self.p.speech.pause())
        audio.on_idle = lambda: (self.p.speech.resume(),
                                 self.emit('orb', 'listening' if self.state.mode is Mode.ACTIVE else 'standby'))

    # ---- lifecycle ----
    def start(self):
        self.emit('mode', self.state.mode.value)
        self.p.speech.start_wake()

    def _lang(self):
        return self.settings.get('ui_language', 'fa')

    def _on_mode(self, mode):
        self.emit('mode', mode.value)
        if mode is Mode.ACTIVE:
            self.p.speech.start_command(self.settings.get('recognition_language', 'fa'))
        elif mode is Mode.STANDBY:
            self._unduck(); self.router.conv.clear(); self.p.speech.start_wake(); self.emit('orb', 'standby')
        else:
            self._unduck(); self.router.conv.clear(); self.p.speech.stop(); self.emit('orb', 'disabled')

    # ---- events from speech engine / UI ----
    def on_wake(self, manual=False):
        ok = self.state.force_activate() if manual else self.state.activate()
        if ok:
            self._duck()
            self.emit('orb', 'listening')
            self._present(Response(['hello' if manual else 'yes'], self._lang()))

    def on_speech(self, text):
        if self.state.mode is Mode.DISABLED:
            return
        if self.state.mode is Mode.STANDBY:        # defensive; detector should only send wake words
            return
        self.state.touch()
        self._duck()
        self.emit('heard', text)
        self.emit('orb', 'processing')
        r = self.router.handle(text)
        self._present(r)
        if r.mode == 'disabled':
            self.state.disable()

    def manual_disable(self):
        self.audio.stop(); self.state.disable()

    def manual_enable(self):
        self.state.enable()

    def _present(self, r):
        self._last_reply = self.clock()
        sub = r.subtitle or ' '.join(vtext(r.lang, k) for k in r.keys)
        self.emit('subtitle', sub)
        if r.success is False:
            self.emit('orb', 'error')
        elif r.success:
            self.emit('orb', 'success')
        self.audio.play(r.lang, r.keys, interrupt=True)

    # ---- music ducking around an interaction ----
    def _duck(self):
        if not self._ducked:
            self._ducked = True
            self.p.music.duck(True)

    def _unduck(self):
        if self._ducked:
            self._ducked = False
            self.p.music.duck(False)

    def tick(self):
        if self.state.tick():
            self.router.conv.clear()
        elif (self._ducked and not self.router.conv.pending and not self.audio.busy
              and self.clock() - self._last_reply >= INTERACTION_IDLE_S):
            self._unduck()

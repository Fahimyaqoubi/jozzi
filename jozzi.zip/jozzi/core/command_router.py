"""Maps parsed intents to platform actions and runs the multi-turn flows."""
import time
from datetime import datetime
from config import CREATOR_FA, CREATOR_EN
from .conversation_manager import ConversationManager, Choice
from .intent_parser import parse, is_yes, is_no, pick_index
from .response_manager import Response, text as vtext, fmt_time
from .text_normalizer import normalize
from .time_parser import parse_time, detect_period, to_24h

MOM = {'مامان', 'مادر', 'mom', 'mother', 'mum', 'mommy', 'maman'}


def _last4(num):
    d = ''.join(ch for ch in num if ch.isdigit())
    return '…' + d[-4:] if d else ''


class CommandRouter:
    def __init__(self, platform, aliases, now_fn=datetime.now, clock=time.monotonic):
        self.p, self.aliases, self.now = platform, aliases, now_fn
        self.conv = ConversationManager(clock)

    # ---------- helpers ----------
    def _r(self, lang, keys, subtitle='', **kw):
        return Response(list(keys), lang, subtitle or ' '.join(vtext(lang, k) for k in keys), **kw)

    @staticmethod
    def _t(lang, fa, en):
        return fa if lang == 'fa' else en

    # ---------- entry ----------
    def handle(self, text: str) -> Response:
        intent = parse(text)
        self.conv.check_timeout()                 # stale question -> treated as new command
        if self.conv.pending:
            r = self._followup(self.conv.pending, intent)
            if r is not None:
                return r
        return self._dispatch(intent)

    # ---------- follow-ups (never mistaken for new commands) ----------
    def _followup(self, p, it):
        L, body, n = p.lang, it.body, normalize(it.body)
        if it.name == 'CANCEL':
            self.conv.clear(); return self._r(L, ['cancelled'])
        if it.name == 'STOP_LISTEN':
            self.conv.clear(); return None
        if it.name == 'WAKE':
            return self._r(L, ['yes'])
        new_cmd = it.name != 'UNKNOWN'
        aw = p.awaiting
        if aw == 'text':                           # anything said now IS the message
            p.slots['text'] = body
            return self._ready(p)
        if aw == 'confirm':
            if is_no(n):
                self.conv.clear(); return self._r(L, ['cancelled'])
            if is_yes(n):
                return self._execute(p)
            if new_cmd:
                self.conv.clear(); return None
            return self._r(L, ['not_understood', 'send_it' if p.kind == 'message' else 'call_confirm'])
        if aw == 'contact_choice':
            i = pick_index(n, len(p.candidates))
            if i is None:
                nn = [c for c in p.candidates if n and n in normalize(c.name)]
                i = p.candidates.index(nn[0]) if len(nn) == 1 else None
            if i is not None:
                return self._with_contact(p.kind, p.slots, L, p.candidates[i])
            if new_cmd:
                self.conv.clear(); return None
            return self._r(L, ['which_one'], self._choices_subtitle(p.candidates, L))
        if aw == 'contact':
            if new_cmd:
                self.conv.clear(); return None
            self.conv.clear()
            return self._contact_step(p.kind, p.slots, L, body)
        if aw == 'time':
            tr = parse_time(body, self.now(), bare=True)
            if tr is None:
                if new_cmd:
                    self.conv.clear(); return None
                return self._r(L, ['what_time'])
            self.conv.clear()
            return self._alarm_from(tr, L)
        if aw == 'period':
            per = detect_period(body)
            if per is None:
                if new_cmd:
                    self.conv.clear(); return None
                return self._r(L, ['am_or_pm'])
            h = to_24h(p.slots['hour12'], per)
            self.conv.clear()
            return self._set_alarm(h, p.slots['minute'], L)
        self.conv.clear()
        return None

    # ---------- dispatch ----------
    def _dispatch(self, it):
        L, n, s = it.lang, it.name, it.slots
        if n == 'WAKE':
            return self._r(L, ['yes'])
        if n == 'STOP_LISTEN':
            self.conv.clear(); return self._r(L, ['listening_off'], mode='disabled')
        if n == 'CANCEL':
            return self._r(L, ['cancelled'])
        if n == 'WHO':
            return Response([], L, CREATOR_FA if L == 'fa' else CREATOR_EN)
        if n in ('MESSAGE', 'CALL'):
            kind = n.lower()
            slots = {'text': s.get('text', ''), 'app': s.get('app')}
            if not s.get('contact'):
                self.conv.begin(kind, slots, 'contact', L)
                return self._r(L, ['to_whom'])
            return self._contact_step(kind, slots, L, s['contact'])
        if n == 'OPEN':
            return self._open_app(s.get('app', ''), L)
        if n == 'ALARM':
            tr = parse_time(it.body, self.now())
            if tr is None:
                self.conv.begin('alarm', {}, 'time', L)
                return self._r(L, ['what_time'])
            return self._alarm_from(tr, L)
        if n.startswith('MUSIC'):
            return self._music(it, L)
        return self._r(L, ['not_understood', 'repeat'])

    # ---------- contacts / messaging / calling ----------
    def _contact_step(self, kind, slots, L, name):
        entry = self.aliases.resolve(name)
        found = self.p.contacts.search(entry['name'] if entry else name)
        choices = [Choice(c.name, num) for c in found for num in c.numbers]
        if entry and entry.get('number'):
            tail = ''.join(ch for ch in entry['number'] if ch.isdigit())[-7:]
            only = [c for c in choices if ''.join(ch for ch in c.number if ch.isdigit()).endswith(tail)]
            choices = only or choices
        slots['spoken'] = name
        if not choices:
            self.conv.clear()
            return self._r(L, ['contact_not_found'], self._t(L, f"مخاطب «{name}» پیدا نشد.",
                                                             f'No contact found for "{name}".'), success=False)
        if len(choices) == 1:
            return self._with_contact(kind, slots, L, choices[0])
        self.conv.begin(kind, slots, 'contact_choice', L, choices)
        return self._r(L, ['which_one'], self._choices_subtitle(choices, L))

    @staticmethod
    def _choices_subtitle(choices, L):
        return '\n'.join(f"{i + 1}) {c.name} {_last4(c.number)}" for i, c in enumerate(choices))

    def _with_contact(self, kind, slots, L, choice):
        slots['choice'] = choice
        p = self.conv.begin(kind, slots, 'confirm', L)
        if kind == 'call':
            return self._r(L, ['call_confirm'], self._t(L, f"به {choice.name} زنگ بزنم؟",
                                                        f"Call {choice.name}?"))
        if not slots.get('text'):
            p.awaiting = 'text'
            key = 'what_to_say_mom' if normalize(slots.get('spoken', '')) in MOM else 'what_to_say'
            return self._r(L, [key], self._t(L, f"چی به {choice.name} بگم؟",
                                             f"What should I tell {choice.name}?"))
        return self._ready(p)

    def _ready(self, p):
        L, ch, txt = p.lang, p.slots['choice'], p.slots['text']
        p.awaiting = 'confirm'; self.conv.refresh()
        sub = self._t(L, f"به: {ch.name}\n«{txt}»\nارسالش کنم؟", f'To: {ch.name}\n"{txt}"\nShall I send it?')
        return self._r(L, ['message_ready', 'send_it'], sub)

    def _execute(self, p):
        L, ch = p.lang, p.slots['choice']
        self.conv.clear()
        if p.kind == 'call':
            ok = self.p.calling.dial(ch.number)
            return self._r(L, ['opening_app'] if ok else ['failed'],
                           self._t(L, 'شماره‌گیر باز شد؛ تماس را خودت بزن.', 'Dialer opened — press call.')
                           if ok else '', success=bool(ok))
        ok = self.p.messaging.open(ch.number, p.slots['text'], p.slots.get('app'))
        # Android gives no delivery receipt: we only claim the app was opened.
        return self._r(L, ['opening_app'] if ok else ['failed'],
                       self._t(L, 'پیام آماده در برنامه باز شد؛ ارسال نهایی با خودته.',
                               'Message opened in the app — press send there.') if ok else '', success=bool(ok))

    # ---------- apps ----------
    def _open_app(self, name, L):
        app = self.p.launcher.find(name)
        if not app:
            return self._r(L, ['app_not_found'], self._t(L, f"برنامه «{name}» پیدا نشد.",
                                                         f'App "{name}" not found.'), success=False)
        ok = self.p.launcher.launch(app)
        return self._r(L, ['opening_app'] if ok else ['failed'], app.label, success=bool(ok))

    # ---------- alarms ----------
    def _alarm_from(self, tr, L):
        if tr.error:
            return self._r(L, ['not_understood', 'what_time'], success=False)
        if tr.needs_period:
            self.conv.begin('alarm', {'hour12': tr.hour12, 'minute': tr.minute}, 'period', L)
            return self._r(L, ['am_or_pm'])
        return self._set_alarm(tr.hour, tr.minute, L, tr.minutes_from_now if tr.relative else 0)

    def _set_alarm(self, h, m, L, rel=0):
        ok = self.p.alarms.set_alarm(h, m, 'Jozzi')
        if not ok:
            return self._r(L, ['failed'], self._t(L, 'سیستم درخواست آلارم را نپذیرفت.',
                                                  'The system did not accept the alarm request.'), success=False)
        t = fmt_time(h, m, L)
        sub = self._t(L, f"آلارم ساعت {t} تنظیم شد", f"Alarm set for {t}")
        if rel:
            sub += self._t(L, f" ({rel} دقیقه دیگر)".translate(str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')),
                           f" (in {rel} min)")
        return self._r(L, ['alarm_set'], sub, success=True)

    # ---------- music ----------
    def _music(self, it, L):
        m, n = self.p.music, it.name
        fail = self._r(L, ['failed'], self._t(L, 'آهنگی پیدا نشد (دسترسی به فایل‌های صوتی؟)',
                                              'No track found (audio permission?)'), success=False)
        if n == 'MUSIC_RANDOM':
            t = m.play_random()
            return self._r(L, ['playing_music'], t, success=True) if t else fail
        if n == 'MUSIC_NAMED':
            t = m.play_named(it.slots['query'])
            return self._r(L, ['playing_music'], t, success=True) if t else fail
        if n == 'MUSIC_NEXT':
            t = m.next()
            return self._r(L, ['next_song'], t, success=True) if t else fail
        if n == 'MUSIC_PREV':
            t = m.prev()
            return self._r(L, [], t, success=True) if t else fail
        if n == 'MUSIC_PAUSE':
            return self._r(L, ['sure']) if m.pause() else fail
        if n == 'MUSIC_RESUME':
            return self._r(L, ['sure']) if m.resume() else fail
        if n == 'MUSIC_STOP':
            return self._r(L, ['music_stopped']) if m.stop() else fail
        if n == 'MUSIC_VOLUME':
            v = m.change_volume(it.slots['delta'])
            return self._r(L, [], f"{int(v * 100)}%", success=True)
        return fail

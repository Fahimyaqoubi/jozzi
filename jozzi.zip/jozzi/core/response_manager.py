from dataclasses import dataclass, field
from typing import List, Optional

# key, Persian, English. First 23 = required list; rest are small extras.
MANIFEST = [
    ('hello', 'سلام!', 'Hello!'),
    ('yes', 'بله؟', 'Yes?'),
    ('listening', 'گوش می‌دم.', "I'm listening."),
    ('sure', 'حتماً.', 'Sure.'),
    ('what_to_say', 'چی می‌خواستی بگی؟', 'What did you want to say?'),
    ('what_to_say_mom', 'چی به مامان بگم؟', 'What should I tell Mom?'),
    ('message_ready', 'متن پیامت آماده شد.', 'Your message is ready.'),
    ('send_it', 'ارسالش کنم؟', 'Shall I send it?'),
    ('done', 'انجامش دادم.', 'Done.'),
    ('cancelled', 'لغو شد.', 'Cancelled.'),
    ('not_understood', 'متوجه نشدم.', "I didn't understand."),
    ('repeat', 'دوباره تکرار می‌کنی؟', 'Could you repeat that?'),
    ('contact_not_found', 'مخاطب موردنظر رو پیدا نکردم.', "I couldn't find that contact."),
    ('app_not_found', 'برنامه موردنظر رو پیدا نکردم.', "I couldn't find that app."),
    ('what_time', 'برای چه ساعتی؟', 'For what time?'),
    ('am_or_pm', 'صبح یا شب؟', 'AM or PM?'),
    ('alarm_set', 'آلارم تنظیم شد.', 'Alarm set.'),
    ('playing_music', 'در حال پخش موسیقی هستم.', 'Playing music.'),
    ('music_stopped', 'موسیقی متوقف شد.', 'Music stopped.'),
    ('next_song', 'آهنگ بعدی.', 'Next song.'),
    ('opening_app', 'در حال باز کردن برنامه.', 'Opening the app.'),
    ('failed', 'متأسفانه نتونستم انجامش بدم.', "Sorry, I couldn't do that."),
    ('goodbye', 'خداحافظ.', 'Goodbye.'),
    ('call_confirm', 'زنگ بزنم؟', 'Shall I call?'),
    ('which_one', 'کدوم یکی؟', 'Which one?'),
    ('to_whom', 'به کی؟', 'To whom?'),
    ('listening_off', 'باشه، دیگه گوش نمی‌دم.', "Okay, I've stopped listening."),
]
_T = {k: {'fa': fa, 'en': en} for k, fa, en in MANIFEST}


def text(lang, key):
    return _T[key][lang if lang in ('fa', 'en') else 'fa']


@dataclass
class Response:
    keys: List[str] = field(default_factory=list)   # prerecorded clips to queue
    lang: str = 'fa'
    subtitle: str = ''                              # dynamic info is shown, never spoken
    success: Optional[bool] = None
    mode: Optional[str] = None                      # 'disabled' => stop listening


_FA_D = str.maketrans('0123456789', '۰۱۲۳۴۵۶۷۸۹')


def fmt_time(h, m, lang):
    if lang == 'en':
        return f"{(h % 12) or 12}:{m:02d} {'AM' if h < 12 else 'PM'}" if h else f"12:{m:02d} AM"
    if h > 12:
        s = f"{h}:{m:02d}"
    else:
        period = 'صبح' if h < 12 else 'ظهر'
        s = f"{h or 12}:{m:02d} {period if h else 'بامداد'}"
    return s.translate(_FA_D)

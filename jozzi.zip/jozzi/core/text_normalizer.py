"""Persian/English text normalisation. clean() keeps punctuation/case (for message
bodies); normalize() is the aggressive form used for keyword matching."""
import re

_CH = str.maketrans({'ي': 'ی', 'ى': 'ی', 'ك': 'ک', 'ۀ': 'ه', 'ة': 'ه', 'ـ': '',
                     '\u200d': '', '\u200e': '', '\u200f': '', '\u00a0': ' '})
_DIG = str.maketrans('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', '01234567890123456789')
_DIAC = re.compile('[\u064B-\u065F\u0670]')
_WS = re.compile(r'\s+')
_PUNCT = re.compile(r'[^\w\s:]', re.UNICODE)


def unify(t: str) -> str:
    return _DIAC.sub('', t.translate(_CH).translate(_DIG))


def clean(t: str) -> str:
    return _WS.sub(' ', unify(t)).strip()


def normalize(t: str) -> str:
    t = clean(t).lower().replace('\u200c', ' ')   # half-space -> space for matching
    return _WS.sub(' ', _PUNCT.sub(' ', t)).strip()

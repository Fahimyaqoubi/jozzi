"""Rule-based intent parser for Persian / English / mixed commands (no ML)."""
import re
from dataclasses import dataclass, field
from .language_detector import command_language
from .text_normalizer import clean, normalize

WAKE_RE = re.compile(r'^\s*(?:(?:hey|hi|ok|okay|هی)\s+)?(?:jozzi|jozi|joozi|جوزی)\b[\s,:،.!؟?-]*', re.I)
MUSICW = r'(?:[آا]هنگ|موسیقی|song|track|music)'
I = re.I

YES = {'اره', 'آره', 'بله', 'باشه', 'اوکی', 'ok', 'okay', 'yes', 'yeah', 'yep', 'sure', 'بفرست',
       'ارسال', 'بزن', 'send', 'call', 'آرع', 'اوهوم'}
NO = {'نه', 'نخیر', 'نع', 'no', 'nope', 'نخواستم'}


@dataclass
class Intent:
    name: str
    slots: dict = field(default_factory=dict)
    lang: str = 'fa'
    wake: bool = False
    body: str = ''


def _tidy(s):
    return re.sub(r'^[\s.!?,;:،؟]+|[\s.!?,;:،؟]+$', '', s or '')


def _text(s):
    s = (s or '').strip()
    return '' if re.fullmatch(r'[\s.!?,;:،؟]*', s) else s


_APP = r'(تلگرام|واتساپ|واتس اپ|ایتا|بله|whatsapp|telegram|sms|پیامک)'


def _split_app(contact):
    m = re.search(r'\s*(?:در|توی|با|از طریق|via|on|using|in)\s+' + _APP + r'$', contact, I)
    if m:
        a = m.group(1).lower()
        app = {'تلگرام': 'telegram', 'telegram': 'telegram', 'واتساپ': 'whatsapp',
               'واتس اپ': 'whatsapp', 'whatsapp': 'whatsapp'}.get(a, 'sms')
        return contact[:m.start()], app
    return contact, None


def is_yes(n):
    t = n.split()
    return bool(t) and not is_no(n) and (n in YES or t[0] in YES)


def is_no(n):
    t = n.split()
    return bool(t) and (n in NO or t[0] in NO)


_ORD = {'اول': 0, 'اولی': 0, 'یکی': 0, 'یک': 0, '1': 0, 'first': 0, 'one': 0,
        'دوم': 1, 'دومی': 1, 'دو': 1, '2': 1, 'second': 1, 'two': 1,
        'سوم': 2, 'سومی': 2, 'سه': 2, '3': 2, 'third': 2, 'three': 2,
        'چهارم': 3, 'چهارمی': 3, '4': 3, 'fourth': 3}


def pick_index(n, count):
    for tok in n.split():
        i = _ORD.get(tok)
        if i is not None and i < count:
            return i
    return None


def parse(text: str) -> Intent:
    c = clean(text)
    m = WAKE_RE.match(c)
    wake = bool(m)
    body = c[m.end():].strip() if m else c
    lang = command_language(body or c)
    if not body:
        return Intent('WAKE', {}, lang, True, '')
    n = normalize(body)

    def mk(name, **slots):
        return Intent(name, slots, lang, wake, body)

    if re.search(r'گوش نده|گوش نکن|دیگه گوش|stop listening|disable assistant|turn off assistant', n):
        return mk('STOP_LISTEN')
    if re.match(r'^(?:لغو|cancel|بیخیال|ولش کن|فراموشش کن|never ?mind|forget it)\b', n):
        return mk('CANCEL')
    if re.search(r'(?:کی|کیه|چه کسی)\s.*ساخت|سازنده|خالق|who (?:created|made|built|developed) you|'
                 r'your (?:creator|developer|maker)', n):
        return mk('WHO')

    # ---- messaging ----
    contact = text_ = None
    if (m := re.match(r'^(?:send (?:a )?(?:message|text|sms) to|message|text|msg|sms)\s+(?:to\s+)?(.+?)\s+'
                      r'(?:and\s+)?(?:say|saying|that)\s+(.+)$', body, I)):
        contact, text_ = m[1], m[2]
    elif (m := re.match(r'^(?:send (?:a )?(?:message|text|sms) to|message|text|msg|sms)\s+(?:to\s+)?(\S+)'
                        r'(?:\s+(.+))?$', body, I)):
        contact, text_ = m[1], m[2]
    elif (m := re.match(r'^tell\s+(\S+)\s+(?:that\s+)?(.+)$', body, I)):
        contact, text_ = m[1], m[2]
    elif (m := re.match(r'^به\s+(.+?)\s+بگو\s*(?:که\s+)?(.*)$', body)):
        contact, text_ = m[1], m[2]
    elif (m := re.match(r'^(?:به|برای)\s+(.+?)\s+(?:یه\s+)?(?:پیام|پیامک|اس ام اس)\s*'
                        r'(?:بده|بفرست|بزن|ارسال کن)\s*(?:که\s*)?(.*)$', body)):
        contact, text_ = m[1], m[2]
    elif (m := re.match(r'^(?:یه\s+)?(?:پیام|پیامک)\s*(?:بده|بفرست|بزن)\s+(?:به|برای)\s+(.+)$', body)):
        contact, text_ = m[1], ''
    if contact is not None and _tidy(contact).lower() not in ('me', 'us', 'من', 'ما'):
        contact, app = _split_app(_tidy(contact))
        return mk('MESSAGE', contact=_tidy(contact), text=_text(text_), app=app)

    # ---- calling ----
    for pat in (r'^(?:به|با)\s+(.+?)\s+(?:زنگ\s*بزن|تماس\s*بگیر|زنگ\s*بزنم|تماس\s*بگیرم)',
                r'^زنگ\s*بزن\s+به\s+(.+)$', r'^(?:call|phone|ring|dial)\s+(.+?)\s*$'):
        if (m := re.match(pat, body, I)):
            return mk('CALL', contact=_tidy(m[1]))

    if re.search(r'[آا]لارم|alarm|بیدارم کن|wake me', n):
        return mk('ALARM')

    short = len(n.split()) <= 3
    has_music = re.search(MUSICW, n)
    if re.search(r'بعدی|\bnext\b|\bskip\b', n) and (has_music or short):
        return mk('MUSIC_NEXT')
    if re.search(r'قبلی|\bprevious\b|\bprev\b|go back', n) and (has_music or short):
        return mk('MUSIC_PREV')
    if re.search(r'مکث|\bpause\b', n):
        return mk('MUSIC_PAUSE')
    if re.search(r'ادامه|\bresume\b|\bcontinue\b', n) and (has_music or short):
        return mk('MUSIC_RESUME')
    if re.search(r'متوقف|\bstop\b|قطع کن|خاموش کن', n) and (has_music or short):
        return mk('MUSIC_STOP')
    if re.search(r'صدا.*(?:زیاد|بلند|بیشتر)|volume up|louder|turn it up', n):
        return mk('MUSIC_VOLUME', delta=+0.15)
    if re.search(r'صدا.*(?:کم|پایین)|volume down|quieter|lower the volume|turn it down', n):
        return mk('MUSIC_VOLUME', delta=-0.15)

    # ---- open app ----
    for pat in (r'^(.+?)\s+(?:رو|را)\s+(?:باز\s*کن|اجرا\s*کن|باز\s*بکن|اجرا\s*بکن|باز\s*کنید|اجرا\s*کنید|باز\s*کنی)',
                r'^(?:باز\s*کن|اجرا\s*کن)\s+(.+)$',
                r'^(?:please\s+)?(?:open|launch|start|run)\s+(?:the\s+)?(.+?)(?:\s+app)?\s*$'):
        if (m := re.match(pat, body, I)):
            return mk('OPEN', app=_tidy(m[1]))

    # ---- play music ----
    if (m := re.match(r'^play\s+(?:a\s+|the\s+)?(?:song|track)\s+(?:named\s+|called\s+)?(.+)$', body, I)):
        return mk('MUSIC_NAMED', query=_tidy(m[1]))
    if (m := re.match(r'^(?:آهنگ|اهنگ|موسیقی)\s+(.+?)\s+(?:رو|را)\s+(?:پخش\s*کن|بذار|بزن)', body)):
        return mk('MUSIC_NAMED', query=_tidy(m[1]))
    if re.search(r'رندوم|تصادفی|\brandom\b|\bshuffle\b', n) or \
            (has_music and re.search(r'پخش|بذار|بزن|\bplay\b|\bstart\b', n)):
        return mk('MUSIC_RANDOM')
    return mk('UNKNOWN', text=body)

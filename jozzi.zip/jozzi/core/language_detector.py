import re
_FA = re.compile(r'[\u0600-\u06FF]')
_EN = re.compile(r'[A-Za-z]')
_FIRST = re.compile(r'[A-Za-z\u0600-\u06FF]')


def detect(text: str) -> str:
    f, e = len(_FA.findall(text)), len(_EN.findall(text))
    if f and e:
        return 'mixed'
    return 'fa' if f else 'en'


def command_language(text: str) -> str:
    """Language the assistant should answer in: script of the first letter
    (so 'message mom سلام' -> en, 'کلاد open' -> fa)."""
    m = _FIRST.search(text)
    if not m:
        return 'fa'
    return 'fa' if _FA.match(m.group()) else 'en'
